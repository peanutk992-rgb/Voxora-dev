#!/usr/bin/env python3
"""Voxora Launcher - skrip pemasang modifikasi di atas kode sumber Zalith Launcher 2 (GPL-3.0).

Pemakaian (dijalankan dari folder utama kode sumber Zalith):
    python3 patch.py <modul...> [--src FOLDER_PAYLOAD]

Modul:
    base    nama, ID aplikasi, ikon, palet warna Voxora, label "Unofficial Modified Version",
            matikan pengecek update Zalith, tanda tangan release
    ai      kartu Voxora Assistant (dokter crash, pengatur RAM, tanya AI) di layar utama
    shapes  sudut UI lebih bulat (bentuk Voxora)

Setiap perubahan DIPERIKSA: kalau teks yang dicari tidak ada persis sekali, skrip berhenti dengan pesan GAGAL.
"""
import json
import os
import re
import shutil
import sys

ROOT = os.getcwd()
SRC = os.path.dirname(os.path.abspath(__file__))
MOD = "ZalithLauncher"
JAVA_DIR = os.path.join(MOD, "src/main/java")
RES = os.path.join(MOD, "src/main/res")
PKG = os.path.join(JAVA_DIR, "com/movtery/zalithlauncher")


def die(msg):
    print("GAGAL: " + msg)
    sys.exit(1)


def p(*parts):
    return os.path.join(ROOT, *parts)


def read(path):
    with open(p(path), encoding="utf-8") as f:
        return f.read()


def write(path, text):
    full = p(path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)


def sub_once(path, old, new, what):
    """Ganti teks `old` dengan `new`; `old` harus muncul PERSIS sekali."""
    text = read(path)
    n = text.count(old)
    if n != 1:
        die("%s: teks yang dicari muncul %d kali (harus 1) di %s" % (what, n, path))
    write(path, text.replace(old, new))
    print("  ok  " + what)


def sub_re(path, pattern, repl, what, count=1, flags=0):
    text = read(path)
    new, n = re.subn(pattern, repl, text, flags=flags)
    if n != count:
        die("%s: pola cocok %d kali (harus %d) di %s" % (what, n, count, path))
    write(path, new)
    print("  ok  " + what)


def copy_payload(rel_from, rel_to):
    src = os.path.join(SRC, rel_from)
    if not os.path.isfile(src):
        die("file payload tidak ditemukan: " + src)
    dst = p(rel_to)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copyfile(src, dst)
    print("  ok  salin " + rel_to)


# ----------------------------------------------------------------------------- base
def patch_base():
    print("[base] rebrand Voxora")
    props = MOD + "/gradle.properties"
    sub_re(props, r"(?m)^launcher_name=.*$", "launcher_name=VoxoraLauncher", "launcher_name")
    sub_re(props, r"(?m)^launcher_app_name=.*$", "launcher_app_name=Voxora Launcher", "launcher_app_name")
    sub_re(props, r"(?m)^launcher_short_name=.*$", "launcher_short_name=VXL", "launcher_short_name")
    sub_re(props, r"(?m)^launcher_version_name=.*$", "launcher_version_name=2.7.2-voxora1", "launcher_version_name")

    gk = MOD + "/build.gradle.kts"
    sub_once(gk, "applicationId = zalithPackageName", 'applicationId = "app.voxora.launcher"', "applicationId")
    sub_once(gk, '        applicationIdSuffix = ".v2"\n', "", "hapus akhiran .v2")
    sub_once(gk, '            applicationIdSuffix = ".debug"\n', "", "hapus akhiran .debug")
    sub_once(gk, '            versionNameSuffix = "-debug"\n', "", "hapus akhiran -debug")
    sub_once(gk, 'signingConfig = signingConfigs.getByName("releaseBuild")', 'signingConfig = signingConfigs.getByName("debugBuild")',
             "tanda tangan release pakai keystore publik repo")

    # label wajib: Unofficial Modified Version
    splash = PKG + "/ui/screens/splash/SplashScreen.kt"
    sub_re(splash, r"(?m)^([ \t]*)text = BuildKeys\.LAUNCHER_NAME[ \t]*$",
           lambda m: (m.group(1) + 'text = BuildKeys.LAUNCHER_NAME + " - Unofficial Modified Version",\n'
                      + m.group(1) + 'maxLines = 1,\n'
                      + m.group(1) + 'overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,\n'
                      + m.group(1) + 'style = androidx.compose.material3.MaterialTheme.typography.labelLarge'),
           "label tidak resmi di splash", count=1)
    homecards = PKG + "/ui/screens/content/home/HomeCards.kt"
    sub_once(homecards,
             "text = stringResource(R.string.launcher_version_debug_warning, BuildKeys.LAUNCHER_NAME),",
             'text = "Versi Modifikasi Tidak Resmi (Unofficial Modified Version) dari Zalith Launcher 2. Jangan laporkan bug versi ini ke tim Zalith. " + stringResource(R.string.launcher_version_debug_warning, BuildKeys.LAUNCHER_NAME),',
             "label tidak resmi di kartu peringatan")

    # pengecek update bawaan menunjuk ke rilis Zalith asli -> matikan
    sub_once(PKG + "/viewmodel/LauncherUpgradeViewModel.kt",
             "val currentVersionCode = BuildConfig.VERSION_CODE",
             "val currentVersionCode = Int.MAX_VALUE // Voxora: update datang dari build ulang, bukan dari rilis Zalith",
             "matikan notifikasi update Zalith")

    # palet warna Voxora (kolom pertama = tema "Embermire" -> jadi Voxora)
    pal = json.load(open(os.path.join(SRC, "palette.json"), encoding="utf-8"))
    color_kt = PKG + "/ui/theme/Color.kt"
    text = read(color_kt)
    done = 0
    for name, hexv in pal.items():
        pat = re.compile(r"(?m)^(val %s = ColorTheme\()Color\(0xFF[0-9A-Fa-f]{6}\)" % re.escape(name))
        text, n = pat.subn(lambda m: m.group(1) + "Color(0xFF" + hexv + ")", text)
        if n != 1:
            die("palet: peran %s cocok %d kali (harus 1) di Color.kt" % (name, n))
        done += 1
    if done != 70:
        die("palet: hanya %d dari 70 peran" % done)
    write(color_kt, text)
    print("  ok  palet Voxora: 70 warna")

    sub_re(MOD + "/src/main/java/com/movtery/zalithlauncher/setting/AllSettings.kt",
           r"if \(Build\.VERSION\.SDK_INT >= Build\.VERSION_CODES\.S\) ColorThemeType\.DYNAMIC\s*\n\s*else ColorThemeType\.EMBERMIRE",
           "ColorThemeType.EMBERMIRE", "tema bawaan = Voxora")

    # nama tema di semua bahasa
    changed = 0
    res_dir = p(RES)
    for d in sorted(os.listdir(res_dir)):
        f = os.path.join(res_dir, d, "strings.xml")
        if d.startswith("values") and os.path.isfile(f):
            s = open(f, encoding="utf-8").read()
            s2, n = re.subn(r'(<string name="theme_color_embermire"[^>]*>)[^<]*(</string>)', r"\1Voxora\2", s)
            if n:
                open(f, "w", encoding="utf-8", newline="\n").write(s2)
                changed += 1
    if changed < 1:
        die("nama tema: tidak ada strings.xml yang berisi theme_color_embermire")
    print("  ok  nama tema 'Voxora' di %d file bahasa" % changed)

    # ikon
    copy_payload("res/ic_launcher_foreground.xml", RES + "/drawable/ic_launcher_foreground.xml")
    copy_payload("res/ic_launcher_monochrome.xml", RES + "/drawable/ic_launcher_monochrome.xml")
    bg = open(os.path.join(SRC, "res/ic_launcher_background_color.txt"), encoding="utf-8").read().strip()
    sub_re(RES + "/values/ic_launcher_background.xml", r"#FFE08F", bg, "warna latar ikon", flags=re.I)
    img_png = p(RES + "/drawable/img_launcher.png")
    if not os.path.isfile(img_png):
        die("img_launcher.png tidak ditemukan")
    os.remove(img_png)
    copy_payload("res/img_launcher.xml", RES + "/drawable/img_launcher.xml")

    # pemberitahuan modifikasi (hak cipta Zalith TIDAK dihapus)
    write("VOXORA_NOTICE.md", NOTICE)
    print("  ok  VOXORA_NOTICE.md")

    # pemeriksaan akhir
    chk = [
        (props, "launcher_name=VoxoraLauncher"),
        (props, "launcher_app_name=Voxora Launcher"),
        (gk, 'applicationId = "app.voxora.launcher"'),
        (splash, "Unofficial Modified Version"),
        (homecards, "Unofficial Modified Version"),
    ]
    for path, needle in chk:
        if needle not in read(path):
            die("pemeriksaan akhir: '%s' tidak ada di %s" % (needle, path))
    if "applicationIdSuffix" in read(gk):
        die("pemeriksaan akhir: applicationIdSuffix masih ada")
    print("[base] selesai")


NOTICE = """# Voxora Launcher

Voxora Launcher adalah **versi modifikasi tidak resmi (Unofficial Modified Version)** dari
**Zalith Launcher 2** (Copyright (C) 2025-2026 MovTery dan kontributor), dilisensikan GPL-3.0
dengan syarat tambahan dari proyek aslinya. Semua pemberitahuan hak cipta dan file LICENSE asli dipertahankan.

Perubahan oleh Voxora: nama aplikasi dan ID aplikasi, ikon, palet warna dan bentuk UI,
label versi tidak resmi, pengecek update bawaan dimatikan, dan fitur Voxora Assistant
(dokter crash offline, pengatur RAM, tanya AI opsional dengan API key milik pengguna).
Kode sumber perubahan disertakan di artifact "Voxora-source" dan di file .patch.

Voxora Launcher BUKAN produk resmi Minecraft dan tidak berafiliasi dengan Mojang Studios atau Microsoft.
Minecraft adalah merek dagang Mojang Studios. Game tidak disertakan: file game diunduh dari server
resmi Mojang dan memerlukan akun Minecraft Java Edition yang sah untuk bermain online.
Jangan laporkan bug versi ini ke tim Zalith Launcher.
"""


# ----------------------------------------------------------------------------- ai
def patch_ai():
    print("[ai] Voxora Assistant")
    for name in ("Txt", "Finding", "DeviceInfo", "DeviceTuner", "LogTail", "LogSanitizer", "CrashDoctor", "MiniJson", "AiClient", "AiPrompt"):
        copy_payload("java/app/voxora/launcher/ai/%s.java" % name, JAVA_DIR + "/app/voxora/launcher/ai/%s.java" % name)
    copy_payload("kotlin/app/voxora/launcher/ui/VoxoraHub.kt", JAVA_DIR + "/app/voxora/launcher/ui/VoxoraHub.kt")
    sub_once(PKG + "/ui/screens/content/home/HomeCards.kt",
             "fun systemCards(): List<SystemCard> = buildList {\n",
             "fun systemCards(): List<SystemCard> = buildList {\n        add(app.voxora.launcher.ui.voxoraHubCard())\n",
             "pasang kartu Voxora di layar utama")
    print("[ai] selesai")


# ----------------------------------------------------------------------------- shapes
def patch_shapes():
    print("[shapes] bentuk UI Voxora")
    copy_payload("kotlin/app/voxora/launcher/ui/VoxoraTheme.kt", JAVA_DIR + "/app/voxora/launcher/ui/VoxoraTheme.kt")
    sub_once(PKG + "/ui/theme/Theme.kt",
             "            motionScheme = MotionScheme.expressive(),\n",
             "            motionScheme = MotionScheme.expressive(),\n            shapes = app.voxora.launcher.ui.VoxoraShapes,\n",
             "pasang bentuk Voxora di tema")
    print("[shapes] selesai")


def main(argv):
    global SRC
    mods = []
    i = 0
    while i < len(argv):
        if argv[i] == "--src":
            SRC = os.path.abspath(argv[i + 1])
            i += 2
        else:
            mods.append(argv[i])
            i += 1
    if not mods:
        die("sebutkan modul: base | ai | shapes")
    if not os.path.isfile(p(MOD, "build.gradle.kts")):
        die("jalankan dari folder utama kode sumber Zalith Launcher (tidak menemukan %s/build.gradle.kts)" % MOD)
    table = {"base": patch_base, "ai": patch_ai, "shapes": patch_shapes}
    for m in mods:
        if m not in table:
            die("modul tidak dikenal: " + m)
        table[m]()


if __name__ == "__main__":
    main(sys.argv[1:])
