Voxora Launcher - kit build (voxora-kit.zip)
=============================================
Jangan di-extract. Unggah file zip ini apa adanya ke halaman utama repository GitHub-mu
(Add file > Upload files), lalu pasang file build-voxora.yml di .github/workflows/.

Isi zip ini adalah kode sumber perubahan Voxora Launcher yang terbaca:
  patch.py            pemasang modifikasi ke kode Zalith Launcher 2
  java/, kotlin/      Voxora Assistant (dokter crash offline, pengatur RAM, tanya AI) dan bentuk UI
  res/, palette.json  ikon dan palet warna
  build.sh/release.sh skrip build (dengan cadangan otomatis) dan penerbitan ke Releases

Voxora Launcher adalah versi modifikasi TIDAK RESMI (Unofficial Modified Version) dari Zalith Launcher 2
(Copyright (C) 2025-2026 MovTery dan kontributor), lisensi GPL-3.0 beserta syarat tambahan proyek aslinya.
Bukan produk resmi Minecraft; tidak berafiliasi dengan Mojang Studios atau Microsoft.
