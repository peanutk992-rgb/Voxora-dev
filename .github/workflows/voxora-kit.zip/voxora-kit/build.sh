#!/usr/bin/env bash
# Voxora: bangun APK dengan cadangan otomatis. Dijalankan dari folder utama kode sumber Zalith
# (di runner GitHub Actions). Variabel yang dibutuhkan: KIT, ARCH, GITHUB_WORKSPACE, GITHUB_STEP_SUMMARY, GITHUB_OUTPUT.
#   Percobaan 1 : Release + semua fitur Voxora (paling cepat & ringan di HP).
#   Kalau gagal : fitur Voxora yang error dibuang dulu; kalau bukan salah fitur,
#                 pindah ke Debug; terakhir coba tanpa fitur tambahan. Maksimal 4 percobaan.
set +e
set -u

PAY="${KIT:?KIT belum di-set}"
OUT="$GITHUB_WORKSPACE/voxora-out"
mkdir -p "$OUT/apk" "$OUT/source" "$OUT/logs"
# folder hasil/log dan salinan repo pengguna jangan dihitung sebagai perubahan kode
printf '%s\n' 'voxora-out/' 'voxora-me/' >> .git/info/exclude
BASE_SHA="$(git rev-parse HEAD)"
{ java -version; df -h . | tail -n 1; } 2>&1 | tee "$OUT/logs/env.txt"

# hanya jalur ini yang boleh diubah/diambil git (bukan hasil build)
EDITED="ZalithLauncher/build.gradle.kts ZalithLauncher/gradle.properties ZalithLauncher/src/main/java ZalithLauncher/src/main/res VOXORA_NOTICE.md"
CLEAN="ZalithLauncher/src/main/java ZalithLauncher/src/main/res VOXORA_NOTICE.md"

MODS="base ai shapes"   # base = nama/ikon/warna/label, ai = Voxora Assistant, shapes = bentuk UI
VARIANT="Release"
GOT=0
LAST=0
ROWS=""

for n in 1 2 3 4; do
  LAST=$n
  vlc="$(printf '%s' "$VARIANT" | tr '[:upper:]' '[:lower:]')"
  echo "::group::Percobaan $n - $VARIANT - modul [$MODS]"

  git reset -q --hard "$BASE_SHA"
  git clean -fdq -- $CLEAN
  chmod +x gradlew   # git reset mengembalikan gradlew jadi tidak-executable, jadi wajib di dalam loop

  if ! python3 "$PAY/patch.py" $MODS; then
    echo "::endgroup::"
    echo "::warning::Modul [$MODS] gagal dipasang ke kode Zalith."
    ROWS="$ROWS| $n | $VARIANT | $MODS | gagal dipasang |"$'\n'
    if [ "$MODS" = "base" ]; then break; fi
    MODS="base"
    continue
  fi

  git add -A -- $EDITED
  git diff --cached --binary > "$OUT/source/voxora-modifications.patch"

  LOG="$OUT/logs/gradle-$n.log"
  ./gradlew "ZalithLauncher:assemble$VARIANT" "-Darch=$ARCH" --console=plain --stacktrace 2>&1 | tee "$LOG"
  rc=${PIPESTATUS[0]}
  echo "::endgroup::"

  if [ "$rc" -eq 0 ] && ls ZalithLauncher/build/outputs/apk/"$vlc"/*.apk > /dev/null 2>&1; then
    cp ZalithLauncher/build/outputs/apk/"$vlc"/*.apk "$OUT/apk/"
    ROWS="$ROWS| $n | $VARIANT | $MODS | BERHASIL |"$'\n'
    GOT=1
    break
  fi

  # ---- gagal: cari tahu penyebabnya ----
  ERR="$OUT/logs/errors-$n.txt"
  grep -E '^e: |\.java:[0-9]+: error:' "$LOG" | sort -u > "$ERR"
  {
    echo "=== Percobaan $n ($VARIANT, modul: $MODS, arsitektur: $ARCH) ==="
    head -n 60 "$ERR"
    grep -A15 'What went wrong' "$LOG" | head -n 40
    echo "--- 80 baris terakhir log ---"
    tail -n 80 "$LOG"
  } > "$OUT/logs/ringkas-$n.txt"
  VX=$(grep -cE 'app/voxora/launcher/(ai/|ui/VoxoraHub\.kt)' "$ERR")
  SH=$(grep -cE 'app/voxora/launcher/ui/VoxoraTheme\.kt|zalithlauncher/ui/theme/Theme\.kt' "$ERR")
  ROW_VARIANT="$VARIANT"
  ROW_MODS="$MODS"
  changed=0
  why=""
  case " $MODS " in *" ai "*)
    if [ "$VX" -gt 0 ]; then MODS="${MODS/ ai/}"; changed=1; why="error di Voxora Assistant, fitur itu dibuang"; fi ;;
  esac
  case " $MODS " in *" shapes "*)
    if [ "$SH" -gt 0 ]; then MODS="${MODS/ shapes/}"; changed=1; why="${why:+$why; }error di bentuk UI, fitur itu dibuang"; fi ;;
  esac
  if [ "$changed" -eq 0 ]; then
    if [ "$VARIANT" = "Release" ]; then
      VARIANT="Debug"; why="Release gagal, coba Debug"
    elif [ "$MODS" != "base" ]; then
      MODS="base"; why="Debug juga gagal, coba tanpa fitur tambahan"
    else
      ROWS="$ROWS| $n | $ROW_VARIANT | $ROW_MODS | gagal |"$'\n'
      break
    fi
  fi
  ROWS="$ROWS| $n | $ROW_VARIANT | $ROW_MODS | gagal - $why |"$'\n'
done

cp VOXORA_NOTICE.md "$OUT/source/" 2>/dev/null

# ---- ringkasan di halaman run ----
{
  echo "## Voxora Launcher - hasil build"
  echo
  echo "| # | Varian | Modul | Hasil |"
  echo "|---|--------|-------|-------|"
  printf '%s' "$ROWS"
  echo
  if [ "$GOT" -eq 1 ]; then
    echo "**APK jadi** (varian $VARIANT, arsitektur $ARCH, modul: $MODS)."
    if [ "$VARIANT" = "Debug" ]; then
      echo
      echo "Catatan: ini varian Debug (lebih lambat dari Release). Unduh artifact Voxora-build-log dan kirim file ringkas-1.txt ke Claude supaya Release bisa dibenerin."
    fi
  else
    echo "**Build gagal.** Unduh artifact **Voxora-build-log** dan kirim file ringkas-*.txt (atau screenshot ringkasan ini) ke Claude."
    echo
    echo '```'
    head -n 45 "$OUT/logs/ringkas-$LAST.txt" 2>/dev/null
    echo '```'
  fi
} >> "$GITHUB_STEP_SUMMARY"

{
  echo "got=$GOT"
  echo "variant=$VARIANT"
  echo "mods=$MODS"
} >> "$GITHUB_OUTPUT"

if [ "$GOT" -ne 1 ]; then
  echo "::error::Build gagal setelah semua percobaan. Unduh artifact Voxora-build-log (file ringkas-*.txt) dan kirim ke Claude."
  exit 1
fi
