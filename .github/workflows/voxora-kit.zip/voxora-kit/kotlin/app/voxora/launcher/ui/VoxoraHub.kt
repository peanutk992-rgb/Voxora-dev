package app.voxora.launcher.ui

import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.voxora.launcher.ai.AiClient
import app.voxora.launcher.ai.AiPrompt
import app.voxora.launcher.ai.CrashDoctor
import app.voxora.launcher.ai.DeviceInfo
import app.voxora.launcher.ai.DeviceTuner
import app.voxora.launcher.ai.Finding
import app.voxora.launcher.ai.LogSanitizer
import app.voxora.launcher.ai.LogTail
import com.movtery.zalithlauncher.game.launch.LogName
import com.movtery.zalithlauncher.game.version.installed.Version
import com.movtery.zalithlauncher.game.version.installed.VersionsManager
import com.movtery.zalithlauncher.setting.AllSettings
import com.movtery.zalithlauncher.ui.screens.content.home.SystemCard
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

/** Kartu Voxora di layar utama (dipasang lewat HomeCards.systemCards). */
fun voxoraHubCard(): SystemCard = SystemCard(id = "voxora_hub") { VoxoraHub() }

// ------------------------------------------------------------------ bahasa & utilitas

private fun isIndonesian(): Boolean {
    val l = Locale.getDefault().language
    return l == "in" || l == "id"
}

private fun lang(): String = if (isIndonesian()) "id" else "en"

private fun tr(id: String, en: String): String = if (isIndonesian()) id else en

private fun gb(mb: Int): String = String.format(Locale.US, "%.1f GB", mb / 1024.0)

private fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Voxora", text))
    Toast.makeText(ctx, tr("Disalin", "Copied"), Toast.LENGTH_SHORT).show()
}

private fun openUrl(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        // tidak ada browser: abaikan
    }
}

private object VoxoraPrefs {
    private const val FILE = "voxora_ai"

    fun load(ctx: Context): AiClient.Config {
        val sp = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val c = AiClient.Config()
        c.preset = sp.getString("preset", "gemini") ?: "gemini"
        c.apiKey = sp.getString("apiKey", "") ?: ""
        c.model = sp.getString("model", "") ?: ""
        c.baseUrl = sp.getString("baseUrl", "") ?: ""
        return c
    }

    fun save(ctx: Context, c: AiClient.Config) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString("preset", c.preset)
            .putString("apiKey", c.apiKey.trim())
            .putString("model", c.model.trim())
            .putString("baseUrl", c.baseUrl.trim())
            .apply()
    }
}

private fun countMods(version: Version?): Int {
    if (version == null) return 0
    val dir = File(version.getGameDir(), "mods")
    return dir.listFiles { f -> f.isFile && f.name.endsWith(".jar", ignoreCase = true) }?.size ?: 0
}

/** Kumpulkan info HP + game. Jalankan di thread latar belakang. */
private fun collectDevice(context: Context, version: Version?): DeviceInfo {
    val d = DeviceInfo()
    try {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        d.totalRamMb = (mi.totalMem / (1024 * 1024)).toInt()
        d.availRamMb = (mi.availMem / (1024 * 1024)).toInt()
    } catch (_: Exception) {
        // biarkan 0 = tidak diketahui
    }
    try {
        d.allocatedRamMb = version?.getRamAllocation(context) ?: (AllSettings.ramAllocation.getValue() ?: 0)
    } catch (_: Exception) {
        d.allocatedRamMb = 0
    }
    try {
        val base = context.getExternalFilesDir(null) ?: context.filesDir
        d.freeStorageMb = (android.os.StatFs(base.path).availableBytes / (1024 * 1024)).toInt()
    } catch (_: Exception) {
        d.freeStorageMb = -1
    }
    d.androidSdk = Build.VERSION.SDK_INT
    d.abi = Build.SUPPORTED_ABIS.firstOrNull() ?: ""
    d.mcVersion = version?.getVersionInfo()?.minecraftVersion ?: version?.getVersionName() ?: ""
    d.modCount = countMods(version)
    return d
}

/** Gabungkan log game + log JVM + crash report terbaru (ekor saja, supaya ringan). */
private fun readLogs(version: Version): String {
    val sb = StringBuilder()
    val dir = version.getZalithVersionPath()
    val game = File(dir, LogName.GAME.fileName)
    sb.append(LogTail.read(game, 300_000))
    val jvm = File(dir, LogName.JVM.fileName)
    if (jvm.isFile) sb.append('\n').append(LogTail.read(jvm, 60_000))
    val crashDir = File(version.getGameDir(), "crash-reports")
    val newest = crashDir.listFiles { f -> f.isFile && f.name.endsWith(".txt") }?.maxByOrNull { it.lastModified() }
    if (newest != null && (!game.isFile || newest.lastModified() >= game.lastModified() - 600_000L)) {
        sb.append('\n').append(LogTail.read(newest, 120_000))
    }
    return sb.toString()
}

// ------------------------------------------------------------------ keadaan dialog

private class DiagData(
    val result: CrashDoctor.Result,
    val device: DeviceInfo,
    val logText: String,
)

private sealed interface HubDialog {
    data object None : HubDialog
    data object Thinking : HubDialog
    data object AiSettings : HubDialog
    class Diagnosis(val data: DiagData) : HubDialog
    class Ram(val device: DeviceInfo, val rec: Int) : HubDialog
    class Ask(val data: DiagData) : HubDialog
    class Answer(val text: String, val isError: Boolean) : HubDialog
}

private class AiOutcome(val text: String, val isError: Boolean)

// ------------------------------------------------------------------ kartu utama

@Composable
fun VoxoraHub() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val version by VersionsManager.currentVersion.collectAsState()
    var device by remember { mutableStateOf<DeviceInfo?>(null) }
    var dialog by remember { mutableStateOf<HubDialog>(HubDialog.None) }
    var busy by remember { mutableStateOf(false) }
    var aiConfig by remember { mutableStateOf(VoxoraPrefs.load(context)) }
    var aiJob by remember { mutableStateOf<Job?>(null) }

    LaunchedEffect(version) {
        device = withContext(Dispatchers.IO) { collectDevice(context, version) }
    }

    fun diagnose(next: (DiagData) -> HubDialog) {
        val v = version
        scope.launch {
            busy = true
            val data = withContext(Dispatchers.IO) {
                val dev = collectDevice(context, v)
                val text = if (v != null) {
                    try {
                        readLogs(v)
                    } catch (_: Exception) {
                        ""
                    }
                } else ""
                DiagData(CrashDoctor.diagnose(text, dev, lang()), dev, text)
            }
            busy = false
            dialog = next(data)
        }
    }

    fun sendToAi(data: DiagData, question: String) {
        dialog = HubDialog.Thinking
        val cfg = aiConfig
        aiJob = scope.launch {
            val outcome = withContext(Dispatchers.IO) {
                try {
                    val clean = LogSanitizer.sanitize(data.logText, 9000)
                    val user = AiPrompt.user(data.device, data.result, clean, question, lang())
                    AiOutcome(AiClient.ask(cfg, AiPrompt.system(lang()), user, lang()), false)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    AiOutcome(e.message ?: e.toString(), true)
                }
            }
            dialog = HubDialog.Answer(outcome.text, outcome.isError)
        }
    }

    val cs = MaterialTheme.colorScheme
    val dev = device
    val rec = if (dev != null) DeviceTuner.recommendRamMb(dev.totalRamMb, dev.modCount, dev.mcVersion) else 0

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.extraLarge)
            .background(Brush.linearGradient(listOf(cs.primaryContainer, cs.surfaceContainerHigh)))
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(cs.tertiary.copy(alpha = 0.32f), Color.Transparent),
                        center = Offset(size.width, 0f),
                        radius = size.width * 0.75f
                    ),
                    radius = size.width * 0.75f,
                    center = Offset(size.width, 0f)
                )
            }
            .padding(18.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Voxora Assistant",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = cs.onPrimaryContainer
                    )
                    Text(
                        text = tr("Dokter game pintar untuk Minecraft di HP-mu", "Smart game doctor for Minecraft on your phone"),
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onPrimaryContainer
                    )
                }
                Surface(
                    shape = RoundedCornerShape(50),
                    color = cs.tertiaryContainer,
                    contentColor = cs.onTertiaryContainer
                ) {
                    Text(
                        text = if (aiConfig.isReady()) "AI online ✓" else tr("AI offline aktif", "Offline AI on"),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (dev != null) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    InfoChip("RAM " + gb(dev.totalRamMb))
                    InfoChip(tr("Kosong ", "Free ") + gb(dev.availRamMb))
                    val allocText = "Game " + dev.allocatedRamMb + " MB" +
                        (if (rec > 0 && dev.allocatedRamMb != rec) " → " + tr("saran ", "suggest ") + rec else " ✓")
                    InfoChip(allocText)
                }
            }

            if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionTile(
                    emoji = "🩺",
                    title = tr("Cek Masalah", "Check Problems"),
                    subtitle = tr("Baca log & cari penyebab", "Read log & find the cause"),
                    accent = cs.primary,
                    onAccent = cs.onPrimary,
                    onClick = { diagnose { HubDialog.Diagnosis(it) } }
                )
                ActionTile(
                    emoji = "⚡",
                    title = tr("Optimalkan RAM", "Optimize RAM"),
                    subtitle = tr("Atur otomatis sesuai HP", "Auto-tune for your phone"),
                    accent = cs.tertiary,
                    onAccent = cs.onTertiary,
                    onClick = {
                        val d = device ?: collectDevice(context, version)
                        dialog = HubDialog.Ram(d, DeviceTuner.recommendRamMb(d.totalRamMb, d.modCount, d.mcVersion))
                    }
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionTile(
                    emoji = "🤖",
                    title = tr("Tanya AI", "Ask AI"),
                    subtitle = tr("Jawaban lebih lengkap", "Deeper answers"),
                    accent = cs.secondary,
                    onAccent = cs.onSecondary,
                    onClick = { diagnose { HubDialog.Ask(it) } }
                )
                ActionTile(
                    emoji = "⚙️",
                    title = tr("Pengaturan AI", "AI Settings"),
                    subtitle = tr("Kunci API & model", "API key & model"),
                    accent = cs.primary,
                    onAccent = cs.onPrimary,
                    onClick = { dialog = HubDialog.AiSettings }
                )
            }

            Text(
                modifier = Modifier.alpha(0.75f),
                text = "Voxora Launcher · Unofficial Modified Version " +
                    tr("(Versi Modifikasi Tidak Resmi)", "") +
                    " of Zalith Launcher 2 · GPL-3.0",
                style = MaterialTheme.typography.labelSmall,
                color = cs.onPrimaryContainer
            )
        }
    }

    // ---------------------------------------------------------- dialog
    val d = dialog
    when (d) {
        is HubDialog.None -> Unit

        is HubDialog.Thinking -> AlertDialog(
            onDismissRequest = { },
            title = { Text(tr("AI sedang berpikir...", "AI is thinking...")) },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                    Text(tr("Mengirim log yang sudah dibersihkan dan menunggu jawaban.", "Sending the scrubbed log and waiting for the answer."))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    aiJob?.cancel()
                    dialog = HubDialog.None
                }) { Text(tr("Batal", "Cancel")) }
            }
        )

        is HubDialog.Diagnosis -> {
            val data = d.data
            AlertDialog(
                onDismissRequest = { dialog = HubDialog.None },
                title = { Text(tr("Hasil diagnosa", "Diagnosis")) },
                text = {
                    Column(
                        modifier = Modifier.verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (data.result.env.isNotEmpty()) {
                            Text(data.result.env, style = MaterialTheme.typography.labelMedium)
                        }
                        if (data.logText.isBlank()) {
                            Text(
                                tr(
                                    "Belum ada log game untuk versi ini. Jalankan game dulu (atau tunggu sampai crash), lalu tekan Cek Masalah lagi. Di bawah ini pemeriksaan HP-mu.",
                                    "No game log for this version yet. Run the game first (or wait for a crash), then tap Check Problems again. Below is your phone check."
                                ),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        if (data.result.findings.isEmpty()) {
                            Text(
                                tr(
                                    "Tidak ada masalah yang dikenali. Kalau game masih bermasalah, coba Tanya AI.",
                                    "No known problem found. If the game still misbehaves, try Ask AI."
                                ),
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        for (f in data.result.findings) FindingCard(f)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { dialog = HubDialog.Ask(data) }) { Text(tr("Tanya AI", "Ask AI")) }
                },
                dismissButton = {
                    Row {
                        TextButton(onClick = { copyText(context, data.result.toReport(lang(), data.device)) }) { Text(tr("Salin", "Copy")) }
                        TextButton(onClick = { dialog = HubDialog.None }) { Text(tr("Tutup", "Close")) }
                    }
                }
            )
        }

        is HubDialog.Ram -> {
            val same = d.device.allocatedRamMb == d.rec
            AlertDialog(
                onDismissRequest = { dialog = HubDialog.None },
                title = { Text(tr("Optimalkan RAM", "Optimize RAM")) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(DeviceTuner.explain(d.device.totalRamMb, d.device.allocatedRamMb, d.rec, lang()), style = MaterialTheme.typography.bodyMedium)
                        if (d.device.modCount > 0) {
                            Text(
                                tr("Mod terpasang: ", "Installed mods: ") + d.device.modCount,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        if (same) Text(tr("RAM game sudah pas. Tidak perlu diubah.", "Game RAM is already right. No change needed."), style = MaterialTheme.typography.bodyMedium)
                    }
                },
                confirmButton = {
                    if (!same) {
                        TextButton(onClick = {
                            AllSettings.ramAllocation.save(d.rec)
                            val eff = try {
                                version?.getRamAllocation(context)
                            } catch (_: Exception) {
                                null
                            }
                            val msg = if (eff != null && eff != d.rec) {
                                tr(
                                    "Tersimpan, tapi versi ini punya RAM sendiri (" + eff + " MB). Ubah di Pengaturan Versi.",
                                    "Saved, but this version has its own RAM (" + eff + " MB). Change it in Version settings."
                                )
                            } else tr("RAM game diatur ke " + d.rec + " MB", "Game RAM set to " + d.rec + " MB")
                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                            scope.launch { device = withContext(Dispatchers.IO) { collectDevice(context, version) } }
                            dialog = HubDialog.None
                        }) { Text(tr("Terapkan ", "Apply ") + d.rec + " MB") }
                    } else {
                        TextButton(onClick = { dialog = HubDialog.None }) { Text(tr("Tutup", "Close")) }
                    }
                },
                dismissButton = {
                    if (!same) TextButton(onClick = { dialog = HubDialog.None }) { Text(tr("Batal", "Cancel")) }
                }
            )
        }

        is HubDialog.Ask -> {
            val data = d.data
            var question by remember { mutableStateOf("") }
            val ready = aiConfig.isReady()
            AlertDialog(
                onDismissRequest = { dialog = HubDialog.None },
                title = { Text(tr("Tanya AI", "Ask AI")) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            tr(
                                "Log game terakhir (sudah dibersihkan dari nama, token, email, dan IP) dikirim ke penyedia AI pilihanmu. Pertanyaan boleh dikosongkan.",
                                "The latest game log (scrubbed of names, tokens, emails and IPs) is sent to your chosen AI provider. The question is optional."
                            ),
                            style = MaterialTheme.typography.bodySmall
                        )
                        OutlinedTextField(
                            value = question,
                            onValueChange = { question = it },
                            label = { Text(tr("Pertanyaan (opsional)", "Question (optional)")) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (!ready) {
                            Text(
                                tr("Kunci API belum diisi. Buka Pengaturan AI dulu.", "No API key yet. Open AI Settings first."),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                },
                confirmButton = {
                    if (ready) {
                        TextButton(onClick = { sendToAi(data, question) }) { Text(tr("Kirim", "Send")) }
                    } else {
                        TextButton(onClick = { dialog = HubDialog.AiSettings }) { Text(tr("Pengaturan AI", "AI Settings")) }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { dialog = HubDialog.None }) { Text(tr("Batal", "Cancel")) }
                }
            )
        }

        is HubDialog.Answer -> AlertDialog(
            onDismissRequest = { dialog = HubDialog.None },
            title = { Text(if (d.isError) tr("AI gagal menjawab", "The AI could not answer") else tr("Jawaban AI", "AI answer")) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    SelectionContainer {
                        Text(
                            text = d.text,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (d.isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            },
            confirmButton = {
                if (d.isError) {
                    TextButton(onClick = { dialog = HubDialog.AiSettings }) { Text(tr("Pengaturan AI", "AI Settings")) }
                } else {
                    TextButton(onClick = { copyText(context, d.text) }) { Text(tr("Salin", "Copy")) }
                }
            },
            dismissButton = {
                TextButton(onClick = { dialog = HubDialog.None }) { Text(tr("Tutup", "Close")) }
            }
        )

        is HubDialog.AiSettings -> AiSettingsDialog(
            initial = aiConfig,
            onSave = { cfg ->
                VoxoraPrefs.save(context, cfg)
                aiConfig = cfg
                dialog = HubDialog.None
            },
            onClose = { dialog = HubDialog.None }
        )
    }
}

// ------------------------------------------------------------------ komponen kecil

@Composable
private fun InfoChip(text: String) {
    Surface(
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.55f),
        contentColor = MaterialTheme.colorScheme.onSurface
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            style = MaterialTheme.typography.labelMedium
        )
    }
}

@Composable
private fun RowScope.ActionTile(
    emoji: String,
    title: String,
    subtitle: String,
    accent: Color,
    onAccent: Color,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.weight(1f),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.62f),
        contentColor = MaterialTheme.colorScheme.onSurface
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(accent),
                contentAlignment = Alignment.Center
            ) {
                Text(text = emoji, fontSize = 20.sp, color = onAccent)
            }
            Column {
                Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall, maxLines = 2)
            }
        }
    }
}

@Composable
private fun FindingCard(f: Finding) {
    val cs = MaterialTheme.colorScheme
    val bg: Color
    val fg: Color
    when (f.severity) {
        Finding.FATAL -> {
            bg = cs.errorContainer
            fg = cs.onErrorContainer
        }
        Finding.LIKELY -> {
            bg = cs.tertiaryContainer
            fg = cs.onTertiaryContainer
        }
        else -> {
            bg = cs.secondaryContainer
            fg = cs.onSecondaryContainer
        }
    }
    Surface(shape = MaterialTheme.shapes.large, color = bg, contentColor = fg) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(text = f.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            if (f.why.isNotEmpty()) Text(text = f.why, style = MaterialTheme.typography.bodySmall)
            f.fixes.forEachIndexed { i, s ->
                Text(text = "" + (i + 1) + ". " + s, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun AiSettingsDialog(
    initial: AiClient.Config,
    onSave: (AiClient.Config) -> Unit,
    onClose: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var presetId by remember { mutableStateOf(initial.preset) }
    var keyText by remember { mutableStateOf(initial.apiKey) }
    var modelText by remember { mutableStateOf(initial.model) }
    var baseText by remember { mutableStateOf(initial.baseUrl) }
    var testing by remember { mutableStateOf(false) }
    var testMsg by remember { mutableStateOf("") }
    val p = AiClient.preset(presetId)

    fun current(): AiClient.Config {
        val c = AiClient.Config()
        c.preset = presetId
        c.apiKey = keyText.trim()
        c.model = modelText.trim()
        c.baseUrl = baseText.trim()
        return c
    }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(tr("Pengaturan AI", "AI Settings")) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    tr(
                        "AI online itu opsional: Dokter offline selalu jalan tanpa kunci. Pakai kunci API milikmu sendiri. Kunci hanya disimpan di HP ini dan hanya dikirim ke penyedia yang kamu pilih.",
                        "Online AI is optional: the offline doctor always works without a key. Use your own API key. It is stored only on this phone and sent only to the provider you pick."
                    ),
                    style = MaterialTheme.typography.bodySmall
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (pr in AiClient.PRESETS) {
                        FilterChip(
                            selected = presetId == pr.id,
                            onClick = { presetId = pr.id },
                            label = { Text(pr.label) }
                        )
                    }
                }
                if (p.keyUrl.isNotEmpty()) {
                    TextButton(onClick = { openUrl(context, p.keyUrl) }) {
                        Text(tr("Ambil kunci API di sini", "Get an API key here"))
                    }
                }
                OutlinedTextField(
                    value = keyText,
                    onValueChange = { keyText = it },
                    label = { Text(tr("Kunci API", "API key")) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = modelText,
                    onValueChange = { modelText = it },
                    label = { Text(tr("Model (kosong = ", "Model (empty = ") + p.model + ")") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (presetId == "custom") {
                    OutlinedTextField(
                        value = baseText,
                        onValueChange = { baseText = it },
                        label = { Text(tr("Alamat server (https://...)", "Server address (https://...)")) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (testing) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                if (testMsg.isNotEmpty()) Text(testMsg, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(current()) }) { Text(tr("Simpan", "Save")) }
        },
        dismissButton = {
            Row {
                TextButton(
                    enabled = !testing,
                    onClick = {
                        val cfg = current()
                        scope.launch {
                            testing = true
                            testMsg = ""
                            testMsg = withContext(Dispatchers.IO) {
                                try {
                                    AiClient.ping(cfg, lang())
                                    "✓ " + tr("Terhubung", "Connected")
                                } catch (e: CancellationException) {
                                    throw e
                                } catch (e: Exception) {
                                    "✗ " + (e.message ?: e.toString())
                                }
                            }
                            testing = false
                        }
                    }
                ) { Text(tr("Tes koneksi", "Test")) }
                TextButton(onClick = onClose) { Text(tr("Batal", "Cancel")) }
            }
        }
    )
}
