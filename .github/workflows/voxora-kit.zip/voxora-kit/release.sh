#!/usr/bin/env bash
# Terbitkan APK ke halaman Releases repository pengguna (biar bisa diunduh langsung tanpa zip).
# Variabel: GH_TOKEN, RUN_NO, RUN_TRY, ARCH, B_VARIANT, B_MODS, GITHUB_REPOSITORY, GITHUB_SERVER_URL, GITHUB_STEP_SUMMARY.
set -euo pipefail
TAG="voxora-${RUN_NO}-${RUN_TRY}-${ARCH}"
{
  echo "Voxora Launcher - versi modifikasi TIDAK RESMI (Unofficial Modified Version) dari Zalith Launcher 2."
  echo
  echo "- Varian: ${B_VARIANT}, arsitektur: ${ARCH}, modul: ${B_MODS}"
  echo "- Kode sumber: https://github.com/ZalithLauncher/ZalithLauncher2/tree/bf1e2e9db9bfe6097c7981ae8997a79c3866dd06 ditambah voxora-modifications.patch (terlampir) dan voxora-kit.zip di repository ini. Lisensi GPL-3.0."
  echo "- Bukan produk resmi Minecraft dan tidak berafiliasi dengan Mojang/Microsoft. Game dibeli terpisah."
} > release-notes.md
gh release create "$TAG" voxora-out/apk/*.apk voxora-out/source/voxora-modifications.patch \
  --repo "$GITHUB_REPOSITORY" \
  --title "Voxora Launcher #${RUN_NO} (${ARCH})" \
  --notes-file release-notes.md
echo "### Unduh APK: ${GITHUB_SERVER_URL}/${GITHUB_REPOSITORY}/releases/tag/${TAG}" >> "$GITHUB_STEP_SUMMARY"
