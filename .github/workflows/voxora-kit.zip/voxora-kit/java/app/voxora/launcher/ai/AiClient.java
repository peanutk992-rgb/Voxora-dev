package app.voxora.launcher.ai;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.List;

/** Klien AI online (opsional). Memakai API key milik pengguna sendiri; kunci hanya dikirim ke penyedia yang dipilih. */
public final class AiClient {
    private AiClient() {
    }

    public static final class Preset {
        public final String id;
        public final String label;
        public final boolean anthropic;
        public final String baseUrl;
        public final String model;
        public final String keyUrl;

        Preset(String id, String label, boolean anthropic, String baseUrl, String model, String keyUrl) {
            this.id = id;
            this.label = label;
            this.anthropic = anthropic;
            this.baseUrl = baseUrl;
            this.model = model;
            this.keyUrl = keyUrl;
        }
    }

    public static final Preset[] PRESETS = {
            new Preset("gemini", "Google Gemini (gratis)", false, "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.5-flash", "https://aistudio.google.com/apikey"),
            new Preset("groq", "Groq (gratis)", false, "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile", "https://console.groq.com/keys"),
            new Preset("openrouter", "OpenRouter", false, "https://openrouter.ai/api/v1", "meta-llama/llama-3.3-70b-instruct:free", "https://openrouter.ai/keys"),
            new Preset("anthropic", "Anthropic (Claude)", true, "https://api.anthropic.com", "claude-haiku-5-5", "https://console.anthropic.com/settings/keys"),
            new Preset("openai", "OpenAI", false, "https://api.openai.com/v1", "gpt-4o-mini", "https://platform.openai.com/api-keys"),
            new Preset("custom", "Lainnya (kompatibel OpenAI)", false, "", "", ""),
    };

    public static final class Config {
        public String preset = "gemini";
        public String apiKey = "";
        public String model = "";
        public String baseUrl = "";

        public boolean isReady() {
            return apiKey != null && apiKey.trim().length() > 0;
        }
    }

    public static Preset preset(String id) {
        for (Preset p : PRESETS) if (p.id.equals(id)) return p;
        return PRESETS[0];
    }

    public static String effectiveModel(Config c) {
        if (c.model != null && c.model.trim().length() > 0) return c.model.trim();
        return preset(c.preset).model;
    }

    public static String effectiveBase(Config c) {
        Preset p = preset(c.preset);
        String b = (c.baseUrl != null && c.baseUrl.trim().length() > 0) ? c.baseUrl.trim() : p.baseUrl;
        while (b.endsWith("/")) b = b.substring(0, b.length() - 1);
        return b;
    }

    static boolean isLoopback(String host) {
        return "localhost".equals(host) || host.startsWith("127.") || "::1".equals(host) || "[::1]".equals(host);
    }

    static String requestBody(boolean anthropic, String model, String system, String user) {
        StringBuilder sb = new StringBuilder();
        if (anthropic) {
            sb.append("{\"model\":").append(MiniJson.quote(model))
                    .append(",\"max_tokens\":1024,\"system\":").append(MiniJson.quote(system))
                    .append(",\"messages\":[{\"role\":\"user\",\"content\":").append(MiniJson.quote(user)).append("}]}");
        } else {
            sb.append("{\"model\":").append(MiniJson.quote(model))
                    .append(",\"messages\":[{\"role\":\"system\",\"content\":").append(MiniJson.quote(system))
                    .append("},{\"role\":\"user\",\"content\":").append(MiniJson.quote(user)).append("}]}");
        }
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    static String extractText(boolean anthropic, String body) {
        Object root = MiniJson.parse(body);
        if (anthropic) {
            Object content = MiniJson.path(root, "content");
            StringBuilder sb = new StringBuilder();
            if (content instanceof List) {
                for (Object o : (List<Object>) content) {
                    Object type = MiniJson.path(o, "type");
                    Object text = MiniJson.path(o, "text");
                    if (text instanceof String && (type == null || "text".equals(type))) sb.append((String) text);
                }
            }
            return sb.toString().trim();
        }
        Object text = MiniJson.path(root, "choices", 0, "message", "content");
        if (text instanceof String) return ((String) text).trim();
        if (text instanceof List) {
            StringBuilder sb = new StringBuilder();
            for (Object o : (List<Object>) text) {
                Object t = MiniJson.path(o, "text");
                if (t instanceof String) sb.append((String) t);
            }
            return sb.toString().trim();
        }
        return "";
    }

    @SuppressWarnings("unchecked")
    static String errorMessage(String body) {
        if (body == null || body.trim().length() == 0) return "";
        try {
            Object root = MiniJson.parse(body);
            if (root instanceof List && !((List<Object>) root).isEmpty()) root = ((List<Object>) root).get(0);
            Object m = MiniJson.path(root, "error", "message");
            if (m instanceof String) return (String) m;
            Object e = MiniJson.path(root, "error");
            if (e instanceof String) return (String) e;
            Object m2 = MiniJson.path(root, "message");
            if (m2 instanceof String) return (String) m2;
        } catch (RuntimeException ignored) {
            // bukan JSON
        }
        String t = body.trim();
        return t.length() > 200 ? t.substring(0, 200) : t;
    }

    static String friendly(int code, String detail, String lang) {
        boolean en = "en".equals(lang);
        String base;
        if (code == 401 || code == 403) base = en ? "The API key was rejected. Check that it is correct and active." : "Kunci API ditolak. Cek apakah kunci benar dan masih aktif.";
        else if (code == 404) base = en ? "Model or address not found. Check the model name / base URL." : "Model atau alamat tidak ditemukan. Cek nama model / alamat.";
        else if (code == 429) base = en ? "Rate limit or quota reached. Wait a bit or check your plan." : "Batas permintaan / kuota habis. Tunggu sebentar atau cek paketmu.";
        else if (code == 400) base = en ? "The provider rejected the request (maybe a wrong model name)." : "Penyedia menolak permintaan (mungkin nama model salah).";
        else if (code >= 500) base = en ? "The AI server is having trouble. Try again later." : "Server AI sedang bermasalah. Coba lagi nanti.";
        else base = en ? "Request failed." : "Permintaan gagal.";
        String d = detail == null ? "" : detail.trim();
        if (d.length() > 160) d = d.substring(0, 160) + "...";
        return base + " (HTTP " + code + (d.length() > 0 ? ": " + d : "") + ")";
    }

    /** Kirim pertanyaan dan tunggu jawaban. Blocking: panggil dari thread latar belakang. */
    public static String ask(Config cfg, String system, String user, String lang) throws IOException {
        boolean en = "en".equals(lang);
        if (cfg == null || !cfg.isReady()) throw new IOException(en ? "API key not set." : "Kunci API belum diisi.");
        Preset p = preset(cfg.preset);
        String base = effectiveBase(cfg);
        String model = effectiveModel(cfg);
        if (base.length() == 0) throw new IOException(en ? "Base URL is empty." : "Alamat (base URL) masih kosong.");
        if (model.length() == 0) throw new IOException(en ? "Model name is empty." : "Nama model masih kosong.");
        URL url;
        try {
            url = URI.create(base + (p.anthropic ? "/v1/messages" : "/chat/completions")).toURL();
        } catch (IllegalArgumentException e) {
            throw new IOException(en ? "The base URL is not valid." : "Alamat (base URL) tidak valid.");
        }
        String host = url.getHost();
        if (!"https".equalsIgnoreCase(url.getProtocol()) && !isLoopback(host)) {
            throw new IOException(en ? "Only https:// addresses are allowed (your key would travel unencrypted)." : "Hanya alamat https:// yang diizinkan (kuncimu bisa tersadap kalau tidak terenkripsi).");
        }
        byte[] payload = requestBody(p.anthropic, model, system, user).getBytes(StandardCharsets.UTF_8);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        try {
            con.setRequestMethod("POST");
            con.setConnectTimeout(15000);
            con.setReadTimeout(90000);
            con.setDoOutput(true);
            con.setRequestProperty("Content-Type", "application/json");
            con.setRequestProperty("Accept", "application/json");
            if (p.anthropic) {
                con.setRequestProperty("x-api-key", cfg.apiKey.trim());
                con.setRequestProperty("anthropic-version", "2023-06-01");
            } else {
                con.setRequestProperty("Authorization", "Bearer " + cfg.apiKey.trim());
            }
            OutputStream os = con.getOutputStream();
            try {
                os.write(payload);
            } finally {
                os.close();
            }
            int code = con.getResponseCode();
            InputStream in = code >= 400 ? con.getErrorStream() : con.getInputStream();
            String body = in == null ? "" : readAll(in, 400000);
            if (code < 200 || code >= 300) throw new IOException(friendly(code, errorMessage(body), lang));
            String text;
            try {
                text = extractText(p.anthropic, body);
            } catch (RuntimeException e) {
                throw new IOException(en ? "Unreadable reply from the AI server." : "Balasan server AI tidak bisa dibaca.");
            }
            if (text.length() == 0) throw new IOException(en ? "The AI returned an empty answer." : "AI memberi jawaban kosong.");
            return text;
        } catch (UnknownHostException e) {
            throw new IOException(en ? "No internet connection (cannot reach " + host + ")." : "Tidak ada koneksi internet (tidak bisa menjangkau " + host + ").");
        } catch (SocketTimeoutException e) {
            throw new IOException(en ? "The AI server took too long. Try again." : "Server AI terlalu lama menjawab. Coba lagi.");
        } finally {
            con.disconnect();
        }
    }

    private static String readAll(InputStream in, int max) throws IOException {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0 && bos.size() < max) bos.write(buf, 0, n);
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        } finally {
            in.close();
        }
    }

    /** Uji cepat kunci tanpa log: dipakai tombol "Tes koneksi". */
    public static String ping(Config cfg, String lang) throws IOException {
        return ask(cfg, "Reply with one short word.", "ping", lang);
    }
}
