package app.voxora.launcher.ai;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** JSON kecil tanpa dependensi: cukup untuk membangun permintaan dan membaca balasan API AI. */
public final class MiniJson {
    private final String s;
    private int i;

    private MiniJson(String s) {
        this.s = s;
    }

    /** Hasil: Map (objek), List (larik), String, Double, Boolean, atau null. */
    public static Object parse(String text) {
        MiniJson p = new MiniJson(text == null ? "" : text);
        p.ws();
        Object v = p.value(0);
        p.ws();
        if (p.i != p.s.length()) throw new IllegalArgumentException("JSON: sisa teks di posisi " + p.i);
        return v;
    }

    /** Telusuri: kunci String untuk objek, Integer untuk larik. Mengembalikan null bila tidak ada. */
    @SuppressWarnings("unchecked")
    public static Object path(Object root, Object... keys) {
        Object cur = root;
        for (Object k : keys) {
            if (cur == null) return null;
            if (k instanceof String && cur instanceof Map) {
                cur = ((Map<String, Object>) cur).get(k);
            } else if (k instanceof Integer && cur instanceof List) {
                List<Object> l = (List<Object>) cur;
                int idx = (Integer) k;
                cur = idx >= 0 && idx < l.size() ? l.get(idx) : null;
            } else {
                return null;
            }
        }
        return cur;
    }

    public static String quote(String v) {
        StringBuilder sb = new StringBuilder(v.length() + 16);
        sb.append('"');
        for (int k = 0; k < v.length(); k++) {
            char ch = v.charAt(k);
            switch (ch) {
                case '"':
                    sb.append("\\\"");
                    break;
                case '\\':
                    sb.append("\\\\");
                    break;
                case '\n':
                    sb.append("\\n");
                    break;
                case '\r':
                    sb.append("\\r");
                    break;
                case '\t':
                    sb.append("\\t");
                    break;
                case '\b':
                    sb.append("\\b");
                    break;
                case '\f':
                    sb.append("\\f");
                    break;
                default:
                    if (ch < 0x20) sb.append(String.format("\\u%04x", (int) ch));
                    else sb.append(ch);
            }
        }
        return sb.append('"').toString();
    }

    private void ws() {
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == ' ' || c == '\n' || c == '\r' || c == '\t') i++;
            else break;
        }
    }

    private Object value(int depth) {
        if (depth > 64) throw new IllegalArgumentException("JSON: terlalu dalam");
        if (i >= s.length()) throw new IllegalArgumentException("JSON: berakhir terlalu cepat");
        char c = s.charAt(i);
        if (c == '{') return object(depth);
        if (c == '[') return array(depth);
        if (c == '"') return string();
        if (s.startsWith("true", i)) {
            i += 4;
            return Boolean.TRUE;
        }
        if (s.startsWith("false", i)) {
            i += 5;
            return Boolean.FALSE;
        }
        if (s.startsWith("null", i)) {
            i += 4;
            return null;
        }
        return number();
    }

    private Map<String, Object> object(int depth) {
        Map<String, Object> m = new LinkedHashMap<String, Object>();
        i++;
        ws();
        if (i < s.length() && s.charAt(i) == '}') {
            i++;
            return m;
        }
        while (true) {
            ws();
            if (i >= s.length() || s.charAt(i) != '"') throw new IllegalArgumentException("JSON: kunci objek di posisi " + i);
            String k = string();
            ws();
            if (i >= s.length() || s.charAt(i) != ':') throw new IllegalArgumentException("JSON: titik dua di posisi " + i);
            i++;
            ws();
            m.put(k, value(depth + 1));
            ws();
            if (i >= s.length()) throw new IllegalArgumentException("JSON: objek tidak ditutup");
            char c = s.charAt(i++);
            if (c == ',') continue;
            if (c == '}') return m;
            throw new IllegalArgumentException("JSON: karakter tak terduga di posisi " + (i - 1));
        }
    }

    private List<Object> array(int depth) {
        List<Object> l = new ArrayList<Object>();
        i++;
        ws();
        if (i < s.length() && s.charAt(i) == ']') {
            i++;
            return l;
        }
        while (true) {
            ws();
            l.add(value(depth + 1));
            ws();
            if (i >= s.length()) throw new IllegalArgumentException("JSON: larik tidak ditutup");
            char c = s.charAt(i++);
            if (c == ',') continue;
            if (c == ']') return l;
            throw new IllegalArgumentException("JSON: karakter tak terduga di posisi " + (i - 1));
        }
    }

    private String string() {
        StringBuilder sb = new StringBuilder();
        i++;
        while (true) {
            if (i >= s.length()) throw new IllegalArgumentException("JSON: string tidak ditutup");
            char c = s.charAt(i++);
            if (c == '"') return sb.toString();
            if (c != '\\') {
                sb.append(c);
                continue;
            }
            if (i >= s.length()) throw new IllegalArgumentException("JSON: escape terpotong");
            char e = s.charAt(i++);
            switch (e) {
                case '"':
                    sb.append('"');
                    break;
                case '\\':
                    sb.append('\\');
                    break;
                case '/':
                    sb.append('/');
                    break;
                case 'b':
                    sb.append('\b');
                    break;
                case 'f':
                    sb.append('\f');
                    break;
                case 'n':
                    sb.append('\n');
                    break;
                case 'r':
                    sb.append('\r');
                    break;
                case 't':
                    sb.append('\t');
                    break;
                case 'u':
                    if (i + 4 > s.length()) throw new IllegalArgumentException("JSON: \\u terpotong");
                    sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                    i += 4;
                    break;
                default:
                    throw new IllegalArgumentException("JSON: escape tidak dikenal \\" + e);
            }
        }
    }

    private Double number() {
        int start = i;
        while (i < s.length()) {
            char c = s.charAt(i);
            if ((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.' || c == 'e' || c == 'E') i++;
            else break;
        }
        if (start == i) throw new IllegalArgumentException("JSON: nilai tidak dikenal di posisi " + i);
        return Double.valueOf(s.substring(start, i));
    }
}
