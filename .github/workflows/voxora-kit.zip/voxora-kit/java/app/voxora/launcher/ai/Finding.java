package app.voxora.launcher.ai;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Satu temuan diagnosa: apa masalahnya, kenapa, dan cara memperbaiki. */
public final class Finding {
    public static final int HINT = 1;
    public static final int LIKELY = 2;
    public static final int FATAL = 3;

    public final String id;
    public final int severity;
    public final String title;
    public final String why;
    public final List<String> fixes;

    public Finding(String id, int severity, String title, String why, List<String> fixes) {
        this.id = id;
        this.severity = severity;
        this.title = title;
        this.why = why;
        this.fixes = Collections.unmodifiableList(new ArrayList<String>(fixes));
    }

    /** Teks polos (untuk disalin / dikirim ke AI). */
    public String toPlain() {
        StringBuilder sb = new StringBuilder();
        sb.append("* ").append(title).append('\n');
        if (why != null && why.length() > 0) sb.append("  ").append(why).append('\n');
        for (int i = 0; i < fixes.size(); i++) {
            sb.append("  ").append(i + 1).append(". ").append(fixes.get(i)).append('\n');
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        return "Finding[" + id + ", sev=" + severity + ", " + title + "]";
    }
}
