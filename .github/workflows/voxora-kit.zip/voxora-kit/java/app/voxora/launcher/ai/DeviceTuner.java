package app.voxora.launcher.ai;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Pengatur RAM: menyarankan jatah RAM (-Xmx) yang stabil untuk HP.
 * Terlalu kecil = lag/crash, terlalu besar = Android mematikan game. Angka di sini adalah titik tengah yang aman.
 */
public final class DeviceTuner {
    private DeviceTuner() {
    }

    // batas atas RAM total (MB) -> {vanilla, modded}
    private static final int[] TOTAL_LIMIT = {2500, 3500, 4500, 6500, 8500, 12500};
    private static final int[] VANILLA = {768, 1024, 1536, 2048, 2560, 3072, 3584};
    private static final int[] MODDED = {768, 1280, 1792, 2560, 3328, 4096, 5120};

    /** Batas atas aman: RAM total dikurangi cadangan untuk Android (sama dengan batas slider Zalith). */
    public static int maxSafeRamMb(int totalMb) {
        if (totalMb <= 0) return 1024;
        if (totalMb < 2048) return Math.min(1024, totalMb);
        return totalMb - (totalMb < 3064 ? 800 : 1024);
    }

    /** Angka "minor" versi Minecraft: 1.20.1 -> 20, versi bergaya tahun (26.1.2) -> 100, tidak dikenal -> -1. */
    public static int mcMinor(String v) {
        if (v == null) return -1;
        Matcher m = Pattern.compile("(\\d+)\\.(\\d+)").matcher(v);
        if (!m.find()) return -1;
        int a = Integer.parseInt(m.group(1));
        int b = Integer.parseInt(m.group(2));
        if (a == 1) return b;
        if (a >= 24) return 100;
        return -1;
    }

    /** Saran RAM (MB) untuk game. */
    public static int recommendRamMb(int totalMb, int modCount, String mcVersion) {
        if (totalMb <= 0) return 1536;
        int idx = TOTAL_LIMIT.length;
        for (int i = 0; i < TOTAL_LIMIT.length; i++) {
            if (totalMb < TOTAL_LIMIT[i]) {
                idx = i;
                break;
            }
        }
        int vanilla = VANILLA[idx];
        int modded = MODDED[idx];
        int rec;
        if (modCount >= 15) rec = modded;
        else if (modCount > 0) rec = (vanilla + modded) / 2;
        else rec = vanilla;
        int minor = mcMinor(mcVersion);
        if (minor >= 0 && minor <= 12) rec = Math.min(rec, 2048);
        if (minor >= 17 && rec < 1024) rec = 1024;
        rec = (rec / 128) * 128;
        rec = Math.min(rec, maxSafeRamMb(totalMb));
        return Math.max(rec, 512);
    }

    public static String explain(int totalMb, int allocMb, int recMb, String lang) {
        boolean en = "en".equals(lang);
        StringBuilder sb = new StringBuilder();
        if (en) {
            sb.append("Phone RAM: ").append(totalMb).append(" MB. Current game RAM: ").append(allocMb).append(" MB. Suggested: ").append(recMb).append(" MB.\n");
            sb.append("Too little RAM causes lag and crashes; too much makes Android kill the game. The suggestion leaves enough memory for Android and the GPU.");
        } else {
            sb.append("RAM HP: ").append(totalMb).append(" MB. RAM game sekarang: ").append(allocMb).append(" MB. Saran: ").append(recMb).append(" MB.\n");
            sb.append("RAM kekecilan bikin lag dan crash, kebesaran bikin Android mematikan game. Angka saran menyisakan memori untuk Android dan GPU.");
        }
        return sb.toString();
    }

    /** Pemeriksaan cepat sebelum main: hanya pakai angka perangkat, tidak perlu log. */
    public static List<Finding> preflight(DeviceInfo d, String lang) {
        boolean en = "en".equals(lang);
        List<Finding> out = new ArrayList<Finding>();
        int rec = recommendRamMb(d.totalRamMb, d.modCount, d.mcVersion);
        int safe = maxSafeRamMb(d.totalRamMb);
        List<String> fix = new ArrayList<String>();

        if (d.totalRamMb > 0 && d.allocatedRamMb > safe) {
            fix.clear();
            fix.add(en ? "Tap \"Optimize RAM\" (suggested " + rec + " MB)." : "Tekan \"Optimalkan RAM\" (saran " + rec + " MB).");
            out.add(new Finding("pre_ram_high", Finding.LIKELY,
                    en ? "Game RAM is too high for this phone" : "Jatah RAM game kebesaran untuk HP ini",
                    en ? "The game gets " + d.allocatedRamMb + " MB of " + d.totalRamMb + " MB total. Android will likely kill it (black screen / sudden exit)."
                            : "Game dikasih " + d.allocatedRamMb + " MB dari total " + d.totalRamMb + " MB. Android kemungkinan akan mematikannya (layar hitam / tiba-tiba keluar).",
                    fix));
        } else if (d.totalRamMb > 0 && d.allocatedRamMb > 0 && d.allocatedRamMb * 10 < rec * 6 && (d.modCount >= 15 || mcMinor(d.mcVersion) >= 17)) {
            fix.clear();
            fix.add(en ? "Tap \"Optimize RAM\" (suggested " + rec + " MB)." : "Tekan \"Optimalkan RAM\" (saran " + rec + " MB).");
            out.add(new Finding("pre_ram_low", Finding.HINT,
                    en ? "Game RAM may be too low" : "Jatah RAM game mungkin kurang",
                    en ? "Only " + d.allocatedRamMb + " MB for a modern/modded game. Expect lag or out-of-memory crashes."
                            : "Cuma " + d.allocatedRamMb + " MB untuk game modern/bermod. Bisa lag atau crash kehabisan memori.",
                    fix));
        }
        if (d.freeStorageMb >= 0 && d.freeStorageMb < 1500) {
            fix.clear();
            fix.add(en ? "Free up at least 3 GB (delete unused versions, worlds backups, videos)." : "Kosongkan minimal 3 GB (hapus versi game yang tak dipakai, backup dunia, video).");
            out.add(new Finding("pre_storage_low", Finding.LIKELY,
                    en ? "Storage is almost full" : "Penyimpanan hampir penuh",
                    en ? "Only " + d.freeStorageMb + " MB free. Downloads and world saving can fail."
                            : "Tinggal " + d.freeStorageMb + " MB. Unduhan dan penyimpanan dunia bisa gagal.",
                    fix));
        }
        if (d.availRamMb > 0 && d.allocatedRamMb > 0 && d.availRamMb < d.allocatedRamMb + 300) {
            fix.clear();
            fix.add(en ? "Close other apps (especially browsers and social media) before playing." : "Tutup aplikasi lain (terutama browser dan media sosial) sebelum main.");
            out.add(new Finding("pre_avail_low", Finding.HINT,
                    en ? "Little free RAM right now" : "RAM kosong saat ini sedikit",
                    en ? "Free RAM: " + d.availRamMb + " MB, game wants " + d.allocatedRamMb + " MB."
                            : "RAM kosong: " + d.availRamMb + " MB, game minta " + d.allocatedRamMb + " MB.",
                    fix));
        }
        return out;
    }
}
