package app.voxora.launcher.ai;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/** Membersihkan log dari data pribadi sebelum disalin / dikirim ke AI online, dan memotongnya jadi ringkas. */
public final class LogSanitizer {
    private LogSanitizer() {
    }

    private static final Pattern[] PATTERNS = {
            Pattern.compile("(?i)(--(?:accessToken|uuid|username|xuid|clientId|userProperties|session))(\\s+)\\S+"),
            Pattern.compile("(?i)(access_?token|session_?id|authorization|bearer|api[_-]?key|x-api-key|client_?secret|refresh_?token)([\"'\\s:=]+)[A-Za-z0-9._\\-]{12,}"),
            Pattern.compile("eyJ[A-Za-z0-9_\\-]{10,}\\.[A-Za-z0-9_\\-]{10,}\\.[A-Za-z0-9_\\-]{10,}"),
            Pattern.compile("\\bsk-[A-Za-z0-9_\\-]{16,}"),
            Pattern.compile("\\bAIza[0-9A-Za-z_\\-]{30,}"),
            Pattern.compile("\\bgsk_[A-Za-z0-9]{20,}"),
            Pattern.compile("[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}"),
            Pattern.compile("\\b(?!(?:10|127|192\\.168|172\\.(?:1[6-9]|2\\d|3[01])|0)\\.)(?:\\d{1,3}\\.){3}\\d{1,3}\\b(?!\\.\\d)"),
            Pattern.compile("(?i)(Setting user:\\s*)\\S+"),
            Pattern.compile("(?i)(/home/|/Users/)[^/\\s\"']+"),
            Pattern.compile("(?i)([A-Z]:\\\\Users\\\\)[^\\\\\\s\"']+"),
    };
    private static final String[] REPLACEMENTS = {
            "$1$2[HIDDEN]",
            "$1$2[HIDDEN]",
            "[TOKEN]",
            "[KEY]",
            "[KEY]",
            "[KEY]",
            "[EMAIL]",
            "[IP]",
            "$1[USER]",
            "$1[USER]",
            "$1[USER]",
    };
    private static final Pattern STORAGE = Pattern.compile("/storage/emulated/\\d+/|/sdcard/");
    private static final Pattern DATA_USER = Pattern.compile("/data/(?:user|data)/\\d*/?[A-Za-z0-9_.]+/");
    private static final Pattern INTERESTING = Pattern.compile(
            "(?i)exception|error|caused by|crash|fatal|failed|cannot|could not|unable|invalid|missing|incompatible|mixin|requires|outofmemory|sigsegv|sigabrt|killed|exit");

    /** Hapus data pribadi saja (tanpa memotong). */
    public static String scrub(String log) {
        if (log == null) return "";
        String s = log;
        for (int i = 0; i < PATTERNS.length; i++) {
            s = PATTERNS[i].matcher(s).replaceAll(REPLACEMENTS[i]);
        }
        s = STORAGE.matcher(s).replaceAll("/sdcard/");
        s = DATA_USER.matcher(s).replaceAll("/data/app/");
        return s;
    }

    /** Bersihkan lalu ringkas jadi paling banyak maxChars (kepala + baris penting + ekor log). */
    public static String sanitize(String log, int maxChars) {
        String s = scrub(log);
        if (s.length() <= maxChars) return s;
        String[] lines = s.split("\n", -1);
        int n = lines.length;
        boolean[] keep = new boolean[n];
        int headLines = Math.min(30, n);
        for (int i = 0; i < headLines; i++) keep[i] = true;
        int tailLines = Math.min(110, n);
        for (int i = n - tailLines; i < n; i++) keep[i] = true;
        for (int i = headLines; i < n - tailLines; i++) {
            if (INTERESTING.matcher(lines[i]).find()) {
                for (int j = Math.max(0, i - 1); j <= Math.min(n - 1, i + 2); j++) keep[j] = true;
            }
        }
        List<String> kept = new ArrayList<String>();
        boolean gap = false;
        for (int i = 0; i < n; i++) {
            if (keep[i]) {
                if (gap) kept.add("[...]");
                String ln = lines[i];
                if (ln.length() > 400) ln = ln.substring(0, 400) + "...";
                kept.add(ln);
                gap = false;
            } else {
                gap = true;
            }
        }
        StringBuilder sb = new StringBuilder();
        for (String ln : kept) sb.append(ln).append('\n');
        String out = sb.toString();
        if (out.length() > maxChars) {
            int headChars = Math.min(2500, maxChars / 4);
            out = out.substring(0, headChars) + "\n[...]\n" + out.substring(out.length() - (maxChars - headChars - 8));
        }
        return out;
    }
}
