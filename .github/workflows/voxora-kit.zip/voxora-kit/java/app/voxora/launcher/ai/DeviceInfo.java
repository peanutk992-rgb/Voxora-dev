package app.voxora.launcher.ai;

/** Info perangkat & game yang dipakai untuk diagnosa (semua angka dalam MB; 0 / -1 = tidak diketahui). */
public final class DeviceInfo {
    public int totalRamMb;
    public int availRamMb;
    public int allocatedRamMb;
    public int freeStorageMb = -1;
    public int androidSdk;
    public String abi = "";
    public String mcVersion = "";
    public int modCount = -1;

    public DeviceInfo() {
    }

    public DeviceInfo(int totalRamMb, int availRamMb, int allocatedRamMb, int freeStorageMb) {
        this.totalRamMb = totalRamMb;
        this.availRamMb = availRamMb;
        this.allocatedRamMb = allocatedRamMb;
        this.freeStorageMb = freeStorageMb;
    }
}
