package app.voxora.launcher.ai;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Dokter crash offline: membaca log Minecraft dan mengenali penyebab umum
 * (RAM, versi Java, mod bentrok, grafis, file rusak, dll) tanpa internet dan tanpa API key.
 */
public final class CrashDoctor {
    private CrashDoctor() {
    }

    public static final class Result {
        public final List<Finding> findings = new ArrayList<Finding>();
        public String env = "";
        public String loader = "";
        public String mcVersion = "";
        public String javaVersion = "";
        public int modCount = -1;
        public boolean crashed;
        public String rootCause = "";
        public int recommendedRamMb;

        public boolean hasFatal() {
            for (Finding f : findings) if (f.severity >= Finding.FATAL) return true;
            return false;
        }

        /** Laporan teks polos untuk disalin. */
        public String toReport(String lang, DeviceInfo dev) {
            boolean en = "en".equals(lang);
            StringBuilder sb = new StringBuilder();
            sb.append("Voxora Assistant - ").append(en ? "diagnosis report" : "laporan diagnosa").append('\n');
            if (env.length() > 0) sb.append(env).append('\n');
            if (dev != null) {
                sb.append("RAM ").append(dev.totalRamMb).append(" MB, ").append(en ? "game" : "game").append(' ').append(dev.allocatedRamMb)
                        .append(" MB, Android SDK ").append(dev.androidSdk).append(", ").append(dev.abi).append('\n');
            }
            sb.append('\n');
            if (findings.isEmpty()) sb.append(en ? "No known problem pattern found.\n" : "Tidak ada pola masalah yang dikenali.\n");
            for (Finding f : findings) sb.append(f.toPlain()).append('\n');
            if (rootCause.length() > 0) sb.append(en ? "Last cause in log: " : "Penyebab terakhir di log: ").append(rootCause).append('\n');
            return sb.toString();
        }
    }

    // ---------------------------------------------------------------- aturan umum (tabel)

    private static final class Rule {
        final String id;
        final int sev;
        final boolean weak;
        final Pattern pat;
        final Txt title;
        final Txt why;
        final Txt[] fixes;

        Rule(String id, int sev, boolean weak, String regex, Txt title, Txt why, Txt... fixes) {
            this.id = id;
            this.sev = sev;
            this.weak = weak;
            this.pat = Pattern.compile(regex);
            this.title = title;
            this.why = why;
            this.fixes = fixes;
        }
    }

    private static final List<Rule> RULES = new ArrayList<Rule>();

    private static Txt t(String id, String en) {
        return Txt.of(id, en);
    }

    private static void add(Rule r) {
        RULES.add(r);
    }

    static {
        add(new Rule("oom_heap", Finding.FATAL, false,
                "java\\.lang\\.OutOfMemoryError:\\s*(?:Java heap space|GC overhead limit exceeded|Requested array size exceeds VM limit)",
                t("RAM game habis (Java heap penuh)", "Game ran out of RAM (Java heap full)"),
                t("Game butuh memori lebih besar dari jatah RAM yang diatur ({alloc} MB). Biasanya karena banyak mod, shader, texture pack besar, atau render distance tinggi.",
                        "The game needed more memory than the {alloc} MB it was given. Usually caused by many mods, shaders, big texture packs or a high render distance."),
                t("Naikkan RAM game ke sekitar {ram} MB (tombol Optimalkan RAM di kartu Voxora).", "Raise game RAM to about {ram} MB (Optimize RAM button on the Voxora card)."),
                t("Turunkan Render Distance ke 6-8 chunk dan matikan shader.", "Lower Render Distance to 6-8 chunks and turn shaders off."),
                t("Kurangi mod berat atau texture pack beresolusi tinggi.", "Remove heavy mods or high-resolution texture packs.")));

        add(new Rule("oom_native", Finding.FATAL, false,
                "OutOfMemoryError:\\s*(unable to create (?:new )?native thread|Metaspace|Direct buffer memory|Compressed class space)",
                t("Memori sistem/native habis", "Native/system memory exhausted"),
                t("Bukan heap Java, tapi memori di luar heap ({g}). Android membatasi jumlah thread dan memori native.",
                        "Not the Java heap but memory outside it ({g}). Android limits threads and native memory."),
                t("Tutup aplikasi lain lalu coba lagi.", "Close other apps and try again."),
                t("Turunkan RAM game sedikit (saran {ram} MB) supaya sisa memori sistem lebih lega.", "Lower game RAM a bit (suggested {ram} MB) to leave more memory for the system."),
                t("Hapus mod yang membuat banyak proses/thread.", "Remove mods that spawn many threads.")));

        add(new Rule("killed_by_system", Finding.LIKELY, false,
                "(?i)lowmemorykiller|Out of memory: Kill|\\bSIGKILL\\b|\\bsignal 9\\b|(?:exit(?:ed)?(?: with)?(?: code)?|code)[:= ]+(?:137|-9)\\b",
                t("Game dimatikan paksa oleh Android", "Android force-killed the game"),
                t("Android mematikan aplikasi yang memakai terlalu banyak RAM saat memori HP menipis. Sering terjadi kalau jatah RAM game ({alloc} MB) terlalu besar untuk HP dengan RAM {total} MB.",
                        "Android kills apps that use too much RAM when memory runs low. Common when game RAM ({alloc} MB) is too high for a {total} MB phone."),
                t("Atur RAM game ke {ram} MB (Optimalkan RAM).", "Set game RAM to {ram} MB (Optimize RAM)."),
                t("Tutup aplikasi lain sebelum main (browser, media sosial).", "Close other apps before playing (browser, social media)."),
                t("Matikan shader dan turunkan Render Distance.", "Turn shaders off and lower Render Distance.")));

        add(new Rule("vm_reserve", Finding.FATAL, false,
                "Could not reserve enough space for[^\\n]{0,60}heap|Invalid maximum heap size|Too small (?:initial|maximum) heap|Error occurred during initialization of VM",
                t("Java gagal start: RAM yang diminta terlalu besar", "Java could not start: requested RAM too large"),
                t("HP tidak bisa menyediakan {alloc} MB sekaligus untuk game.", "The phone cannot provide {alloc} MB for the game at once."),
                t("Turunkan RAM game ke {ram} MB.", "Lower game RAM to {ram} MB."),
                t("Cek kolom JVM args: hapus -Xmx / -Xms yang kamu isi manual.", "Check the JVM args field: remove any -Xmx / -Xms you typed by hand."),
                t("Mulai ulang launcher lalu coba lagi.", "Restart the launcher and try again.")));

        add(new Rule("jvm_option", Finding.FATAL, false,
                "Unrecognized (?:VM )?option[: ]+'?([^'\\n]{1,60})|Unrecognized option: (\\S+)",
                t("Argumen JVM tidak valid", "Invalid JVM argument"),
                t("Java menolak argumen: {g}. Biasanya argumen itu untuk versi Java lain.", "Java rejected the argument: {g}. It is usually meant for another Java version."),
                t("Buka Pengaturan > JVM args (global atau per-versi) lalu hapus argumen tadi.", "Open Settings > JVM args (global or per-version) and remove that argument."),
                t("Atau pilih versi Java yang mendukung argumen itu.", "Or pick a Java version that supports it.")));

        add(new Rule("no_such_method", Finding.LIKELY, false,
                "(?:NoSuchMethodError|NoSuchFieldError|AbstractMethodError|IncompatibleClassChangeError|VerifyError|IllegalAccessError|BootstrapMethodError)[: ]+([^\\n]{0,140})",
                t("Versi mod/pustaka tidak cocok", "Mod/library version mismatch"),
                t("Ada kode yang memanggil bagian yang tidak ada di versi ini: {g}. Tandanya mod dibuat untuk versi Minecraft lain, atau mod dan API-nya beda versi.",
                        "Some code calls something that does not exist in this version: {g}. Usually a mod built for another Minecraft version, or a mod and its API on different versions."),
                t("Update semua mod (dan API-nya, mis. Fabric API) ke versi yang cocok dengan Minecraft {mc}.", "Update all mods (and their API, e.g. Fabric API) to versions matching Minecraft {mc}."),
                t("Hapus mod yang terakhir kamu tambahkan lalu coba lagi.", "Remove the mod you added last and retry."),
                t("Pastikan semua mod untuk loader yang sama ({loader}).", "Make sure every mod is for the same loader ({loader}).")));

        add(new Rule("gl_error", Finding.LIKELY, true,
                "GLFW error (?:before init: )?[\\[(]?(?:0x)?[0-9A-Fa-f]{3,8}|Failed to create (?:window|OpenGL context)|GLX: Failed to create context|EGL_BAD_\\w+|requires OpenGL|does not support OpenGL|OpenGL (?:3\\.2|4\\.\\d) (?:is )?(?:required|not supported)|Pixel format not accelerated|The driver does not appear to support OpenGL|Couldn't set pixel format",
                t("Masalah grafis (OpenGL / renderer)", "Graphics problem (OpenGL / renderer)"),
                t("GPU/renderer HP tidak bisa membuat jendela game. Minecraft baru butuh OpenGL 3.2 ke atas, dan tiap renderer (GL4ES, ANGLE, MobileGlues, Zink) beda kemampuannya.",
                        "The phone GPU/renderer could not create the game window. Newer Minecraft needs OpenGL 3.2+, and each renderer (GL4ES, ANGLE, MobileGlues, Zink) differs."),
                t("Buka Pengaturan > Renderer lalu ganti renderer (MC 1.17+: coba ANGLE / MobileGlues / Zink; MC lama: GL4ES).", "Open Settings > Renderer and switch (MC 1.17+: try ANGLE / MobileGlues / Zink; older MC: GL4ES)."),
                t("Matikan shader dan mod grafis (Sodium/OptiFine/Iris) untuk tes.", "Turn off shaders and graphics mods (Sodium/OptiFine/Iris) to test."),
                t("Kalau pakai driver Turnip/Vulkan, coba driver bawaan sistem.", "If you use the Turnip/Vulkan driver, try the system driver.")));

        add(new Rule("shader_error", Finding.LIKELY, true,
                "(?i)(?:failed to compile|compilation failed|could not compile|error compiling)[^\\n]{0,60}shader|shader[^\\n]{0,40}(?:failed|error)[^\\n]{0,60}compil|GLSL[^\\n]{0,60}error|\\b0:\\d+\\(\\d+\\): error:",
                t("Shader gagal dikompilasi", "Shader failed to compile"),
                t("Shader pack atau mod grafis memakai fitur yang tidak didukung GPU/renderer HP ini.", "A shader pack or graphics mod uses a feature this phone GPU/renderer does not support."),
                t("Matikan shader pack (atau pilih yang lebih ringan).", "Turn the shader pack off (or pick a lighter one)."),
                t("Ganti renderer di Pengaturan > Renderer.", "Switch renderer in Settings > Renderer.")));

        add(new Rule("lwjgl_native", Finding.FATAL, false,
                "UnsatisfiedLinkError|Failed to locate library: ([\\w.\\-]+)|dlopen failed[^\\n]{0,120}|cannot locate symbol",
                t("Library bawaan game gagal dimuat", "A native library failed to load"),
                t("File library ({g0}) hilang, rusak, atau tidak cocok dengan arsitektur HP.", "Library file ({g0}) is missing, corrupted or does not match the phone architecture."),
                t("Pasang ulang Java runtime dan renderer dari pengaturan launcher.", "Reinstall the Java runtime and renderer from the launcher settings."),
                t("Coba renderer lain.", "Try another renderer."),
                t("Kalau tetap gagal, hapus lalu pasang ulang versi game ini.", "If it still fails, delete and reinstall this game version.")));

        add(new Rule("game_files_corrupt", Finding.FATAL, false,
                "Could not find or load main class[^\\n]{0,80}|ClassNotFoundException:\\s*net\\.minecraft\\.client\\.main\\.Main|ZipException[^\\n]{0,80}|zip END header not found|Invalid or corrupt jarfile[^\\n]{0,60}|error in opening zip file[^\\n]{0,60}|SHA-?1 (?:mismatch|check failed)",
                t("File game rusak atau tidak lengkap", "Game files are corrupted or incomplete"),
                t("Ada file game/library/mod yang rusak (biasanya unduhan terputus). Detail: {g0}", "A game/library/mod file is damaged (usually an interrupted download). Detail: {g0}"),
                t("Buka Pengaturan Versi lalu lengkapi/verifikasi file game, atau hapus dan unduh ulang versi ini.", "Open Version settings and verify/complete the game files, or delete and re-download this version."),
                t("Cek folder mods: file .jar mod yang rusak juga memicu ini, unduh ulang mod-nya.", "Check the mods folder: a damaged mod .jar triggers this too, re-download it."),
                t("Pastikan penyimpanan cukup dan koneksi stabil saat mengunduh.", "Make sure there is enough storage and a stable connection when downloading.")));

        add(new Rule("no_space", Finding.FATAL, false,
                "No space left on device|ENOSPC|There is not enough space on the disk",
                t("Penyimpanan penuh", "Storage is full"),
                t("HP kehabisan ruang sehingga game tidak bisa menulis file.", "The phone ran out of space so the game cannot write files."),
                t("Kosongkan minimal 3 GB (hapus versi game, backup, video yang tak dipakai).", "Free at least 3 GB (delete unused game versions, backups, videos)."),
                t("Coba lagi setelah ruang cukup.", "Retry once there is enough space.")));

        add(new Rule("perm_denied", Finding.LIKELY, true,
                "AccessDeniedException[^\\n]{0,100}|Permission denied[^\\n]{0,80}|\\bEACCES\\b|Read-only file system|\\bEROFS\\b",
                t("Folder game tidak bisa diakses", "The game folder cannot be accessed"),
                t("Game tidak diizinkan menulis/membaca: {g0}", "The game is not allowed to read/write: {g0}"),
                t("Pakai folder game di penyimpanan internal (bukan kartu SD / USB).", "Use a game folder on internal storage (not an SD card / USB)."),
                t("Beri izin penyimpanan / 'Akses semua file' bila diminta.", "Grant storage / 'All files access' permission if asked."),
                t("Jangan taruh game di folder milik aplikasi lain.", "Do not put the game in another app's folder.")));

        add(new Rule("network_fail", Finding.LIKELY, true,
                "UnknownHostException:?\\s*([\\w.\\-]+)?|SocketTimeoutException|ConnectException|SSLHandshakeException|PKIX path building failed|Network is unreachable|Connection (?:timed out|reset|refused)|Unable to resolve host",
                t("Masalah koneksi internet", "Internet connection problem"),
                t("Game/launcher gagal terhubung ke server ({g0}).", "The game/launcher could not reach a server ({g0})."),
                t("Cek internet, matikan VPN atau DNS khusus lalu coba lagi.", "Check your internet, turn off VPN or custom DNS and retry."),
                t("Pastikan jam & tanggal HP diatur otomatis (jam salah membuat koneksi aman gagal).", "Make sure the phone date & time are automatic (a wrong clock breaks secure connections)."),
                t("Coba pindah antara WiFi dan data seluler.", "Try switching between WiFi and mobile data.")));

        add(new Rule("auth_fail", Finding.LIKELY, true,
                "Failed to verify username|Invalid session|Authentication servers are down|InvalidCredentialsException|Bad login|multiplayer\\.disconnect\\.(?:unverified_username|invalid_session)|Not authenticated|Unverified username|Session expired|Failed to log in",
                t("Masalah login akun", "Account login problem"),
                t("Sesi akun tidak valid, atau server login Mojang/Microsoft sedang gangguan.", "The account session is invalid, or Mojang/Microsoft login servers are having trouble."),
                t("Keluar lalu login ulang akun Microsoft di menu Akun.", "Sign out and sign in again with your Microsoft account in the Account menu."),
                t("Coba lagi beberapa menit kemudian bila server sedang gangguan.", "Retry in a few minutes if the servers are down."),
                t("Server online-mode butuh akun asli yang memiliki Minecraft Java Edition.", "Online-mode servers need a real account that owns Minecraft Java Edition.")));

        add(new Rule("world_corrupt", Finding.LIKELY, false,
                "Failed to load level|Exception reading [^\\n]{0,60}level\\.dat|Failed to read level data|Error while loading world|Failed to load chunk|java\\.io\\.EOFException: Unexpected end of ZLIB input stream|Corrupted chunk|Could not read level",
                t("Dunia (world) rusak", "World data is corrupted"),
                t("Game gagal membaca data dunia ({g0}).", "The game could not read the world data ({g0})."),
                t("Jangan dihapus dulu: salin folder dunia di saves/ sebagai cadangan.", "Do not delete it yet: copy the world folder in saves/ as a backup."),
                t("Coba pulihkan: ganti level.dat dengan level.dat_old di folder dunia itu.", "Try restoring: replace level.dat with level.dat_old in that world folder."),
                t("Untuk dunia bermod: pakai mod yang sama dengan saat dunia dibuat.", "For modded worlds: use the same mods as when the world was created.")));

        add(new Rule("gl_oom", Finding.LIKELY, false,
                "GL_OUT_OF_MEMORY|(?:GL ERROR|OpenGL Error)[^\\n]{0,40}1285|1285: Out of memory",
                t("Memori GPU habis", "GPU memory exhausted"),
                t("GPU kehabisan memori untuk tekstur/shader.", "The GPU ran out of memory for textures/shaders."),
                t("Turunkan Render Distance dan resolusi texture pack.", "Lower Render Distance and texture-pack resolution."),
                t("Matikan shader dan mod grafis berat.", "Turn off shaders and heavy graphics mods."),
                t("Turunkan skala resolusi layar di pengaturan renderer (jika ada).", "Lower the resolution scale in the renderer settings (if available).")));

        add(new Rule("vulkan_zink", Finding.LIKELY, true,
                "VK_ERROR_\\w+|vkCreate\\w+ failed|Failed to create Vulkan (?:instance|device)|(?i:zink)[: ][^\\n]{0,80}(?:fail|error)",
                t("Masalah Vulkan / Zink", "Vulkan / Zink problem"),
                t("Driver Vulkan HP bermasalah atau tidak lengkap ({g0}).", "The phone Vulkan driver is broken or incomplete ({g0})."),
                t("Ganti renderer ke yang berbasis OpenGL ES (GL4ES / ANGLE).", "Switch to an OpenGL ES based renderer (GL4ES / ANGLE)."),
                t("Coba driver Vulkan lain atau driver sistem.", "Try another Vulkan driver or the system driver."),
                t("Matikan shader.", "Turn shaders off.")));

        add(new Rule("wrong_loader", Finding.LIKELY, false,
                "(?i)Invalid or missing mods\\.toml|missing (?:the )?(?:neoforge\\.)?mods\\.toml|Missing required fabric\\.mod\\.json|Could not find required mod metadata|is not a valid (?:Fabric|Quilt|Forge) mod",
                t("Ada mod untuk loader yang salah", "A mod is for the wrong loader"),
                t("Ada mod yang dibuat untuk loader lain (Forge / Fabric / Quilt / NeoForge) sehingga tidak bisa dimuat di {loader}.", "A mod was made for another loader (Forge / Fabric / Quilt / NeoForge) so it cannot load on {loader}."),
                t("Pakai mod yang sesuai loader versimu ({loader}). Mod Forge tidak jalan di Fabric dan sebaliknya.", "Use mods that match your loader ({loader}). Forge mods do not run on Fabric and vice versa."),
                t("Hapus mod yang salah dari folder mods.", "Remove the wrong mod from the mods folder.")));

        add(new Rule("duplicate_mods", Finding.FATAL, false,
                "(?i)DuplicateModsFoundException|Found duplicate mods?|Duplicate mod(?:s)?(?: id)?[^\\n]{0,60}|Mod [^\\n]{0,60}is (?:present|included) more than once",
                t("Mod ganda terdeteksi", "Duplicate mods detected"),
                t("Mod yang sama terpasang lebih dari satu file di folder mods.", "The same mod is installed more than once in the mods folder."),
                t("Buka folder mods, hapus salah satu file dari mod yang sama (simpan versi terbaru).", "Open the mods folder and delete one copy of the same mod (keep the newest)."),
                t("Cek juga mod yang sudah tertanam di modpack.", "Also check mods already bundled in the modpack.")));

        add(new Rule("stack_overflow", Finding.LIKELY, false,
                "StackOverflowError",
                t("Stack overflow (perulangan tak berujung)", "Stack overflow (endless recursion)"),
                t("Sebuah mod atau kode masuk ke perulangan tanpa henti.", "A mod or some code entered an endless loop."),
                t("Hapus mod yang terakhir kamu tambahkan.", "Remove the mod you added last."),
                t("Update mod ke versi terbaru.", "Update mods to the latest version.")));

        add(new Rule("config_error", Finding.LIKELY, true,
                "(?i)Failed to (?:load|parse|read) (?:config|configuration)[^\\n]{0,120}|ParsingException[^\\n]{0,100}|JsonSyntaxException[^\\n]{0,100}|Malformed JSON[^\\n]{0,80}|com\\.electronwill\\.nightconfig[^\\n]{0,80}",
                t("File pengaturan (config) mod rusak", "A mod config file is broken"),
                t("Game gagal membaca file config: {g0}", "The game could not read a config file: {g0}"),
                t("Hapus file config yang bermasalah di folder config/ (akan dibuat ulang otomatis).", "Delete the broken file in the config/ folder (it is recreated automatically)."),
                t("Kalau baru edit manual, cek tanda kutip / koma yang hilang.", "If you edited it by hand, check for a missing quote or comma.")));
    }

    // ---------------------------------------------------------------- pola khusus

    private static final Pattern CRASHED = Pattern.compile(
            "(?i)---- Minecraft Crash Report ----|crash report saved|Game crashed|has crashed|\\[[^\\]\\n]*/FATAL\\]|Exception in thread \"(?:main|Render thread|Client thread)\"|A fatal error has been detected|Incompatible mods found|ModLoadingException|(?:exit(?:ed)?(?: with)?(?: code)?|Process exited with code)[: =]+(?!0\\b)-?\\d+");
    private static final Pattern EXIT_CODE = Pattern.compile("(?i)(?:exit(?:ed)?(?: with)?(?: code)?|Process exited with code)[: =]+(-?\\d+)");
    private static final Pattern FABRIC_ENV = Pattern.compile("Loading Minecraft (\\S+) with (Fabric|Quilt) Loader (\\S+)");
    private static final Pattern FML_MC = Pattern.compile("--fml\\.mcVersion\\s+(\\S+)|Minecraft Version:\\s*([\\w.\\-]+)|--version\\s+(\\d[\\w.\\-]*)");
    private static final Pattern FORGE_VER = Pattern.compile("--fml\\.(neoForge|forge)Version\\s+(\\S+)");
    private static final Pattern JAVA_VER = Pattern.compile("Java Version:\\s*(\\d[\\d._]*)|java\\.version\\s*[=:]\\s*(\\d[\\d._]*)");
    private static final Pattern MOD_COUNT = Pattern.compile("Loading (\\d+) mods?\\b|Found (\\d+) mod(?:s)? ");
    private static final Pattern FORGE_DEP = Pattern.compile("Mod ID: '([^']+)', Requested by: '([^']+)', Expected range: '([^']*)', Actual version: '([^']*)'");
    private static final Pattern MIXIN = Pattern.compile("Mixin apply failed|MixinApplyError|InvalidInjectionException|MixinTransformerError|Mixin transformation of [\\w./$]+ failed|Critical injection failure|org\\.spongepowered\\.asm\\.mixin\\.[\\w.]+Exception");
    private static final Pattern MIXIN_CFG = Pattern.compile("([A-Za-z0-9_\\-.]+?)\\.mixins?\\.json");
    private static final Pattern MIXIN_MOD = Pattern.compile("(?i)from mod ([A-Za-z0-9_\\-]+)");
    private static final Pattern ENTRYPOINT = Pattern.compile("Could not execute entrypoint stage '(\\w+)' due to errors, provided by '([^']+)'");
    private static final Pattern FML_FAIL = Pattern.compile("ModLoadingException:\\s*([^\\n]{2,100}?) has failed to load correctly");
    private static final Pattern NOCLASS = Pattern.compile("(?:NoClassDefFoundError|ClassNotFoundException):?\\s+([A-Za-z0-9_./$]+)");
    private static final Pattern MC_MISMATCH = Pattern.compile("requires version ([^\\n]{1,60}?) of '?Minecraft'? \\(minecraft\\)[^\\n]{0,100}?(?:present|have|found)[: ]+([\\w.\\-]+)");
    private static final Pattern UCV = Pattern.compile("UnsupportedClassVersionError[^\\n]*?class file version (\\d+)\\.\\d+[^\\n]*?(?:up to|versions up to) (\\d+)\\.\\d+");
    private static final Pattern UCV2 = Pattern.compile("class file version (\\d+)\\.\\d+\\)?,? this version of the Java Runtime only recognizes class file versions up to (\\d+)\\.\\d+");
    private static final Pattern NEED_JAVA = Pattern.compile("requires version (\\d+)(?:\\.\\d+)*(?: or later)? of '?(?:Java|java)|(?:requires|needs) Java (?:Runtime )?(?:version )?(\\d+)");
    private static final Pattern NATIVE = Pattern.compile("A fatal error has been detected by the Java Runtime Environment|\\bSIG(?:SEGV|ABRT|BUS|ILL)\\b|Problematic frame");
    private static final Pattern NATIVE_LIB = Pattern.compile("Problematic frame:\\s*#?\\s*[A-Za-z]\\s+\\[?([A-Za-z0-9_.\\-+]+\\.so)|#\\s*C\\s+\\[([A-Za-z0-9_.\\-+]+\\.so)");
    private static final Pattern CONFIG_FILE = Pattern.compile("config[/\\\\][\\w./\\\\\\-]+\\.(?:toml|json5?|cfg|yml|yaml|properties)");
    private static final Pattern DESCRIPTION = Pattern.compile("---- Minecraft Crash Report ----[\\s\\S]{0,400}?Description:\\s*([^\\n]{3,160})");
    private static final Pattern EXC_LINE = Pattern.compile("(?m)^(?:Exception in thread \"[^\"]*\" )?((?:[\\w$]+\\.)+[\\w$]*(?:Exception|Error)\\b[^\\n]{0,200})$");
    private static final Pattern CAUSED_BY = Pattern.compile("(?m)^\\s*Caused by:\\s*([^\\n]{3,220})$");
    private static final Pattern SUSPECT = Pattern.compile("(?m)^\\s*([^\\s][^\\n]*?)\\s*\\(([\\w\\-]+)\\),\\s*Version:\\s*(\\S+)");

    private static String first(Matcher m) {
        for (int i = 1; i <= m.groupCount(); i++) if (m.group(i) != null && m.group(i).length() > 0) return m.group(i);
        return null;
    }

    private static String clip(String s, int max) {
        if (s == null) return "";
        s = s.trim();
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }

    private static final class Ctx {
        String lang;
        int ram;
        int total;
        int alloc;
        String mc = "?";
        String loader = "?";
        boolean en;
    }

    private static String fmt(String s, Matcher m, Ctx c) {
        String g = "?";
        String g0 = "";
        if (m != null) {
            g0 = clip(m.group(), 120);
            String f = first(m);
            g = f != null ? clip(f, 120) : g0;
        }
        return s.replace("{ram}", Integer.toString(c.ram))
                .replace("{total}", Integer.toString(c.total))
                .replace("{alloc}", c.alloc > 0 ? Integer.toString(c.alloc) : "?")
                .replace("{mc}", c.mc)
                .replace("{loader}", c.loader)
                .replace("{g0}", g0)
                .replace("{g}", g);
    }

    private static Finding build(Rule r, Matcher m, Ctx c, int sev) {
        List<String> fixes = new ArrayList<String>();
        for (Txt x : r.fixes) fixes.add(fmt(x.get(c.lang), m, c));
        return new Finding(r.id, sev, fmt(r.title.get(c.lang), m, c), fmt(r.why.get(c.lang), m, c), fixes);
    }

    private static String translateFabricHint(String line, boolean en) {
        String s = line.trim();
        if (en) return s;
        s = s.replaceFirst("^Install ", "Pasang mod ");
        s = s.replaceFirst("^Replace ", "Ganti ");
        s = s.replaceFirst("^Remove ", "Hapus ");
        s = s.replaceFirst("^Update ", "Update ");
        s = s.replace(", any version", " (versi apa saja)").replace(", version ", " versi ").replace(" or later", " atau lebih baru");
        return s;
    }

    // ---------------------------------------------------------------- inti

    public static Result diagnose(String rawLog, DeviceInfo dev, String lang) {
        if (dev == null) dev = new DeviceInfo();
        String log = rawLog == null ? "" : rawLog.replace("\r", "");
        if (log.length() > 500000) log = log.substring(log.length() - 500000);
        Result res = new Result();
        Ctx c = new Ctx();
        c.lang = "en".equals(lang) ? "en" : "id";
        c.en = "en".equals(c.lang);
        boolean en = c.en;

        detectEnv(log, dev, res);
        res.crashed = CRASHED.matcher(log).find();
        res.recommendedRamMb = DeviceTuner.recommendRamMb(dev.totalRamMb, res.modCount >= 0 ? res.modCount : dev.modCount,
                res.mcVersion.length() > 0 ? res.mcVersion : dev.mcVersion);
        c.ram = res.recommendedRamMb;
        c.total = dev.totalRamMb;
        c.alloc = dev.allocatedRamMb;
        c.mc = res.mcVersion.length() > 0 ? res.mcVersion : (dev.mcVersion.length() > 0 ? dev.mcVersion : "?");
        c.loader = res.loader.length() > 0 ? res.loader : "vanilla";

        Map<String, Finding> out = new LinkedHashMap<String, Finding>();

        // --- khusus: versi Java
        {
            Matcher m = UCV.matcher(log);
            int need = -1, have = -1;
            if (m.find()) {
                need = Integer.parseInt(m.group(1)) - 44;
                have = Integer.parseInt(m.group(2)) - 44;
            } else {
                Matcher m2 = UCV2.matcher(log);
                if (m2.find()) {
                    need = Integer.parseInt(m2.group(1)) - 44;
                    have = Integer.parseInt(m2.group(2)) - 44;
                } else {
                    Matcher m3 = NEED_JAVA.matcher(log);
                    if (m3.find()) {
                        String g = first(m3);
                        if (g != null) need = Integer.parseInt(g);
                    }
                }
            }
            if (need > 0) {
                List<String> fx = new ArrayList<String>();
                fx.add(en ? "Open Version settings > Java and pick Java " + need + " (or 'Auto')." : "Buka Pengaturan Versi > Java lalu pilih Java " + need + " (atau 'Otomatis').");
                fx.add(en ? "If Java " + need + " is not installed, install it from the launcher Java settings." : "Kalau Java " + need + " belum ada, pasang dulu lewat menu Java di pengaturan launcher.");
                fx.add(en ? "Rule of thumb: MC 1.16 or older = Java 8, 1.17-1.20.4 = Java 17, 1.20.5+ = Java 21 (newer if asked)." : "Patokan umum: MC 1.16 ke bawah = Java 8, 1.17-1.20.4 = Java 17, 1.20.5+ = Java 21 (lebih baru jika diminta).");
                out.put("java_version", new Finding("java_version", Finding.FATAL,
                        en ? "Wrong Java version" : "Versi Java tidak cocok",
                        en ? "This game/mod needs Java " + need + (have > 0 ? " but Java " + have + " is being used." : ".")
                                : "Game/mod ini butuh Java " + need + (have > 0 ? ", tapi yang dipakai Java " + have + "." : "."),
                        fx));
            }
        }

        // --- khusus: Fabric/Quilt "Incompatible mods found"
        if (log.contains("Incompatible mods found") || log.contains("Some of your mods are incompatible")) {
            List<String> fx = new ArrayList<String>();
            int idx = log.indexOf("A potential solution");
            if (idx >= 0) {
                int end = log.indexOf("More details", idx);
                String seg = log.substring(idx, end > idx ? end : Math.min(log.length(), idx + 1500));
                Matcher m = Pattern.compile("(?m)^[ \\t]*-\\s+((?:Install|Replace|Remove|Update|Upgrade)\\b[^\\n]{3,200})$").matcher(seg);
                Set<String> seen = new LinkedHashSet<String>();
                while (m.find() && seen.size() < 5) seen.add(translateFabricHint(m.group(1), en));
                fx.addAll(seen);
            }
            if (fx.isEmpty()) {
                Matcher m = Pattern.compile("(?m)^[ \\t]*-\\s+(Mod '[^\\n]{5,250})$").matcher(log);
                int n = 0;
                while (m.find() && n++ < 3) fx.add(clip(m.group(1), 200));
            }
            fx.add(en ? "Download the mentioned mods from the Download menu (match Minecraft " + c.mc + ")." : "Unduh mod yang disebut lewat menu Download (sesuaikan dengan Minecraft " + c.mc + ").");
            out.put("fabric_incompatible", new Finding("fabric_incompatible", Finding.FATAL,
                    en ? "Mods missing or incompatible (" + (res.loader.length() > 0 ? res.loader : "Fabric") + ")" : "Ada mod yang kurang atau tidak cocok (" + (res.loader.length() > 0 ? res.loader : "Fabric") + ")",
                    en ? "The mod loader found mods that need other mods or do not fit this game version." : "Loader mod menemukan mod yang butuh mod lain atau tidak cocok dengan versi game ini.",
                    fx));
        }

        // --- khusus: Forge/NeoForge dependensi hilang
        {
            Matcher m = FORGE_DEP.matcher(log);
            List<String> lines = new ArrayList<String>();
            Set<String> ids = new LinkedHashSet<String>();
            while (m.find() && lines.size() < 5) {
                String id = m.group(1), by = m.group(2), range = m.group(3), actual = m.group(4);
                boolean missing = actual.contains("MISSING");
                if (!ids.add(id + "<" + by)) continue;
                lines.add(en ? "Mod '" + by + "' needs '" + id + "' " + range + (missing ? " (not installed)" : " (installed: " + actual + ")")
                        : "Mod '" + by + "' butuh '" + id + "' " + range + (missing ? " (belum terpasang)" : " (terpasang: " + actual + ")"));
            }
            if (!lines.isEmpty()) {
                List<String> fx = new ArrayList<String>(lines);
                fx.add(en ? "Install/update those mods from the Download menu (match Minecraft " + c.mc + " and your loader)." : "Pasang/update mod itu lewat menu Download (sesuaikan Minecraft " + c.mc + " dan loader-mu).");
                out.put("forge_missing_dep", new Finding("forge_missing_dep", Finding.FATAL,
                        en ? "Required mods are missing" : "Ada mod pendukung yang kurang",
                        en ? "Some mods need other mods (or newer versions of them)." : "Beberapa mod membutuhkan mod lain (atau versi yang lebih baru).",
                        fx));
            }
        }

        // --- khusus: entrypoint Fabric / gagal muat Forge
        {
            Matcher m = ENTRYPOINT.matcher(log);
            if (m.find()) {
                String mod = m.group(2);
                List<String> fx = new ArrayList<String>();
                fx.add(en ? "Update the mod '" + mod + "' to a version that matches Minecraft " + c.mc + " (or remove it temporarily)." : "Update mod '" + mod + "' ke versi yang cocok dengan Minecraft " + c.mc + " (atau hapus sementara).");
                fx.add(en ? "Make sure Fabric API and the mods it depends on are installed." : "Pastikan Fabric API dan mod pendukungnya terpasang.");
                out.put("mod_entrypoint", new Finding("mod_entrypoint", Finding.FATAL,
                        en ? "Mod \"" + mod + "\" failed to start" : "Mod \"" + mod + "\" gagal dimuat",
                        en ? "It crashed during the '" + m.group(1) + "' stage. Usually a version mismatch with Minecraft or another mod." : "Error saat tahap '" + m.group(1) + "'. Biasanya tidak cocok dengan versi Minecraft atau mod lain.",
                        fx));
            }
            Matcher m2 = FML_FAIL.matcher(log);
            if (m2.find()) {
                String mod = clip(m2.group(1), 80);
                List<String> fx = new ArrayList<String>();
                fx.add(en ? "Update '" + mod + "' to a version that matches Minecraft " + c.mc + " (or remove it temporarily)." : "Update '" + mod + "' ke versi yang cocok dengan Minecraft " + c.mc + " (atau hapus sementara).");
                fx.add(en ? "Check that its required mods are installed." : "Cek mod pendukung yang dibutuhkannya sudah terpasang.");
                out.put("mod_failed_load", new Finding("mod_failed_load", Finding.FATAL,
                        en ? "Mod \"" + mod + "\" failed to load" : "Mod \"" + mod + "\" gagal dimuat",
                        en ? "The loader reports this mod could not load correctly." : "Loader melaporkan mod ini tidak bisa dimuat dengan benar.",
                        fx));
            }
        }

        // --- khusus: Mixin
        {
            Matcher m = MIXIN.matcher(log);
            if (m.find()) {
                Set<String> names = new LinkedHashSet<String>();
                Matcher mm = MIXIN_MOD.matcher(log);
                while (mm.find() && names.size() < 4) names.add(mm.group(1));
                if (names.isEmpty()) {
                    Matcher mc = MIXIN_CFG.matcher(log);
                    while (mc.find() && names.size() < 4) {
                        String n = mc.group(1);
                        if (n.length() > 1 && !n.equals("minecraft")) names.add(n);
                    }
                }
                List<String> fx = new ArrayList<String>();
                if (!names.isEmpty()) fx.add(en ? "Update or temporarily remove: " + join(names) + "." : "Update atau hapus sementara: " + join(names) + ".");
                fx.add(en ? "Remove the mod you added last, then retry." : "Hapus mod yang terakhir kamu tambahkan, lalu coba lagi.");
                fx.add(en ? "Make sure all mods are for Minecraft " + c.mc + " and the same loader (" + c.loader + ")." : "Pastikan semua mod untuk Minecraft " + c.mc + " dan loader yang sama (" + c.loader + ").");
                fx.add(en ? "Look for the same mod installed twice (duplicate versions)." : "Cari mod yang sama terpasang dua kali (versi ganda).");
                fx.add(en ? "Still stuck: move all mods out, then add them back in halves to find the culprit." : "Masih bingung: pindahkan semua mod keluar, lalu masukkan lagi setengah-setengah untuk cari pelakunya.");
                out.put("mixin_fail", new Finding("mixin_fail", Finding.LIKELY,
                        en ? "Mod conflict (Mixin failed)" : "Mod bentrok (Mixin gagal)",
                        (en ? "A mod failed to patch the game code. Common causes: a mod for another Minecraft version, or two mods clashing."
                                : "Ada mod yang gagal memodifikasi kode game. Penyebab umum: mod untuk versi Minecraft lain, atau dua mod saling bentrok.")
                                + (names.isEmpty() ? "" : (en ? " Mods involved: " : " Mod terkait: ") + join(names) + "."),
                        fx));
            }
        }

        // --- khusus: class hilang
        {
            Matcher m = NOCLASS.matcher(log);
            Set<String> classes = new LinkedHashSet<String>();
            while (m.find() && classes.size() < 3) {
                String cl = m.group(1).replace('/', '.');
                if (cl.startsWith("net.minecraft.client.main.Main")) continue;
                classes.add(cl);
            }
            if (!classes.isEmpty()) {
                String cl = classes.iterator().next();
                String low = cl.toLowerCase();
                String guess;
                if (low.contains("fabricmc") || low.contains("fabric.api")) guess = "Fabric API";
                else if (low.contains("kotlin")) guess = en ? "Fabric Language Kotlin / Kotlin for Forge" : "Fabric Language Kotlin / Kotlin for Forge";
                else if (low.contains("architectury")) guess = "Architectury API";
                else if (low.contains("cloth")) guess = "Cloth Config API";
                else if (low.contains("geckolib")) guess = "GeckoLib";
                else if (low.contains("optifine")) guess = "OptiFine";
                else if (low.contains("minecraftforge") || low.contains(".fml.")) guess = "Forge";
                else if (low.contains("neoforged")) guess = "NeoForge";
                else if (low.startsWith("org.lwjgl")) guess = "LWJGL";
                else if (low.startsWith("java.") || low.startsWith("javax.") || low.startsWith("sun.")) guess = en ? "a different Java version" : "versi Java yang berbeda";
                else guess = null;
                List<String> fx = new ArrayList<String>();
                if (guess != null) fx.add(en ? "Install the supporting mod/library: " + guess + "." : "Pasang mod/pustaka pendukung: " + guess + ".");
                fx.add(en ? "Check the mod page for 'Required dependencies' and install them." : "Buka halaman mod itu, lihat bagian 'Dependencies' lalu pasang semuanya.");
                fx.add(en ? "Make sure versions match Minecraft " + c.mc + " and loader " + c.loader + "." : "Pastikan versinya cocok dengan Minecraft " + c.mc + " dan loader " + c.loader + ".");
                out.put("missing_class", new Finding("missing_class", Finding.LIKELY,
                        en ? "A required mod/library is missing or the wrong version" : "Ada mod/pustaka yang kurang atau versinya salah",
                        en ? "The game looked for class '" + clip(cl, 100) + "' but could not find it." : "Game mencari class '" + clip(cl, 100) + "' tetapi tidak menemukannya.",
                        fx));
            }
        }

        // --- khusus: versi Minecraft tidak cocok (Fabric)
        {
            Matcher m = MC_MISMATCH.matcher(log);
            if (m.find()) {
                List<String> fx = new ArrayList<String>();
                fx.add(en ? "Download the mod version built for Minecraft " + m.group(2) + " (filter by game version on the mod page)." : "Unduh versi mod yang dibuat untuk Minecraft " + m.group(2) + " (filter versi game di halaman mod).");
                fx.add(en ? "Or switch to the Minecraft version the mod supports." : "Atau pindah ke versi Minecraft yang didukung mod itu.");
                out.put("mc_mismatch", new Finding("mc_mismatch", Finding.LIKELY,
                        en ? "A mod is for another Minecraft version" : "Ada mod untuk versi Minecraft lain",
                        en ? "A mod needs Minecraft " + clip(m.group(1), 40) + " but you run " + m.group(2) + "." : "Ada mod yang butuh Minecraft " + clip(m.group(1), 40) + ", sedangkan kamu pakai " + m.group(2) + ".",
                        fx));
            }
        }

        // --- khusus: crash native
        if (NATIVE.matcher(log).find()) {
            Matcher ml = NATIVE_LIB.matcher(log);
            String lib = ml.find() ? first(ml) : null;
            String ll = lib == null ? "" : lib.toLowerCase();
            List<String> fx = new ArrayList<String>();
            String kind;
            if (ll.matches(".*(gl4es|libgl|libegl|gles|mobileglues|zink|angle|mesa|virgl|osmesa|vulkan|libvk|tinywrapper|glfw).*")) {
                kind = en ? "the graphics renderer/driver" : "renderer/driver grafis";
                fx.add(en ? "Switch renderer or graphics driver (Settings > Renderer)." : "Ganti renderer atau driver grafis (Pengaturan > Renderer).");
                fx.add(en ? "Turn off shaders and graphics mods." : "Matikan shader dan mod grafis.");
                fx.add(en ? "Lower Render Distance." : "Turunkan Render Distance.");
            } else if (ll.contains("libjvm") || ll.contains("libjava") || ll.contains("libzip") || ll.contains("libnio")) {
                kind = en ? "the Java virtual machine" : "mesin virtual Java";
                fx.add(en ? "Try another Java version for this game version." : "Coba versi Java lain untuk versi game ini.");
                fx.add(en ? "Lower game RAM to " + c.ram + " MB." : "Turunkan RAM game ke " + c.ram + " MB.");
                fx.add(en ? "Remove mods that use native code (performance mods) to test." : "Hapus mod yang memakai kode native (mod performa) untuk tes.");
            } else if (ll.startsWith("libc.") || ll.contains("libart") || ll.contains("libdl") || ll.contains("libm.") || ll.contains("libandroid")) {
                kind = en ? "system memory" : "memori sistem";
                fx.add(en ? "Lower game RAM to " + c.ram + " MB." : "Turunkan RAM game ke " + c.ram + " MB.");
                fx.add(en ? "Close other apps and restart the phone if it keeps happening." : "Tutup aplikasi lain, dan restart HP kalau terus terjadi.");
            } else if (ll.contains("lwjgl")) {
                kind = "LWJGL";
                fx.add(en ? "Reinstall the Java runtime and renderer." : "Pasang ulang Java runtime dan renderer.");
                fx.add(en ? "Try another renderer." : "Coba renderer lain.");
            } else {
                kind = en ? "native code" : "kode native";
                fx.add(en ? "Switch renderer (Settings > Renderer)." : "Ganti renderer (Pengaturan > Renderer).");
                fx.add(en ? "Try another Java version." : "Coba versi Java lain.");
                fx.add(en ? "Turn off shaders and update the launcher." : "Matikan shader dan perbarui launcher.");
            }
            out.put("native_crash", new Finding("native_crash", Finding.FATAL,
                    en ? "The game crashed at system level (native crash)" : "Game crash di level sistem (native)",
                    (en ? "Java aborted inside " : "Java berhenti di dalam ") + kind + (lib != null ? " (" + lib + ")." : "."),
                    fx));
        }

        // --- tabel aturan umum
        for (Rule r : RULES) {
            if (r.sev <= 0) continue;
            Matcher m = r.pat.matcher(log);
            if (!m.find()) continue;
            int sev = r.sev;
            if (r.weak && !res.crashed) sev = Finding.HINT;
            Finding f = build(r, m, c, sev);
            if ("config_error".equals(r.id)) {
                Matcher cf = CONFIG_FILE.matcher(log);
                if (cf.find()) f = new Finding(f.id, f.severity, f.title, f.why, withFirst(f.fixes, (en ? "Delete: " : "Hapus: ") + cf.group().replace('\\', '/')));
            }
            out.put(r.id, f);
        }

        // --- tersangka mod (laporan crash Forge/NeoForge)
        {
            int idx = log.indexOf("Suspected Mod");
            if (idx >= 0) {
                int end = Math.min(log.length(), idx + 700);
                String seg = log.substring(idx, end);
                Matcher m = SUSPECT.matcher(seg);
                List<String> names = new ArrayList<String>();
                while (m.find() && names.size() < 3) names.add(clip(m.group(1), 40) + " (" + m.group(2) + ")");
                if (!names.isEmpty()) {
                    List<String> fx = new ArrayList<String>();
                    fx.add(en ? "Update that mod to the newest version matching Minecraft " + c.mc + "." : "Update mod itu ke versi terbaru yang cocok dengan Minecraft " + c.mc + ".");
                    fx.add(en ? "If it still crashes, remove it temporarily." : "Kalau tetap crash, hapus sementara.");
                    fx.add(en ? "Report to the mod author with the crash report attached." : "Laporkan ke pembuat mod dengan melampirkan crash report.");
                    out.put("suspected_mods", new Finding("suspected_mods", Finding.LIKELY,
                            en ? "Suspected mod(s): " + join(names) : "Mod yang dicurigai: " + join(names),
                            en ? "The crash report points at these mods." : "Laporan crash menunjuk mod ini.",
                            fx));
                }
            }
        }

        // --- kode keluar (petunjuk)
        {
            Matcher m = EXIT_CODE.matcher(log);
            String code = null;
            while (m.find()) code = m.group(1);
            if (code != null && !"0".equals(code) && !out.containsKey("killed_by_system")) {
                String meaning;
                if ("1".equals(code)) meaning = en ? "general error (see the other findings)" : "error umum (lihat temuan lain)";
                else if ("134".equals(code)) meaning = en ? "Java aborted itself (SIGABRT), usually a native/memory crash" : "Java membatalkan diri (SIGABRT), biasanya crash native/memori";
                else if ("139".equals(code)) meaning = en ? "memory/graphics crash (SIGSEGV)" : "crash memori/grafis (SIGSEGV)";
                else if ("143".equals(code)) meaning = en ? "the process was terminated (SIGTERM)" : "proses dihentikan (SIGTERM)";
                else meaning = en ? "abnormal exit" : "keluar tidak normal";
                List<String> fx = new ArrayList<String>();
                fx.add(en ? "Read the other findings first; this code alone does not say what broke." : "Baca temuan lain dulu; kode ini saja tidak menjelaskan apa yang rusak.");
                out.put("exit_code", new Finding("exit_code", Finding.HINT,
                        (en ? "Game exited with code " : "Game berhenti dengan kode ") + code,
                        (en ? "Meaning: " : "Artinya: ") + meaning + ".", fx));
            }
        }

        // --- deskripsi laporan crash Minecraft
        {
            Matcher m = DESCRIPTION.matcher(log);
            if (m.find()) {
                String desc = clip(m.group(1), 140);
                Matcher e = EXC_LINE.matcher(log.substring(m.end()));
                String exc = e.find() ? clip(e.group(1), 200) : "";
                List<String> fx = new ArrayList<String>();
                fx.add(en ? "Use this together with the findings above." : "Gunakan bersama temuan di atas.");
                out.put("crash_description", new Finding("crash_description", Finding.HINT,
                        (en ? "Crash report: " : "Laporan crash: ") + desc,
                        exc.length() > 0 ? exc : "", fx));
            }
        }

        res.rootCause = findRootCause(log);

        // --- pemeriksaan perangkat (selalu)
        for (Finding f : DeviceTuner.preflight(dev, c.lang)) {
            if (!out.containsKey(f.id)) out.put(f.id, f);
        }

        // --- tidak ada yang cocok
        boolean hasReal = false;
        for (Finding f : out.values()) if (!f.id.startsWith("pre_") && !"exit_code".equals(f.id) && !"crash_description".equals(f.id)) hasReal = true;
        if (!hasReal && res.rootCause.length() > 0) {
            List<String> fx = new ArrayList<String>();
            fx.add(en ? "Tap 'Ask AI' for a deeper explanation of this error." : "Tekan 'Tanya AI' untuk penjelasan lebih dalam tentang error ini.");
            fx.add(en ? "Search the exact error line on the mod's or Minecraft's issue tracker." : "Cari baris error persis ini di halaman issue mod / Minecraft.");
            fx.add(en ? "Remove the last mod/resource pack you added and retry." : "Hapus mod / resource pack terakhir yang kamu tambah lalu coba lagi.");
            out.put("unknown", new Finding("unknown", Finding.HINT,
                    en ? "Error found, but not a known pattern" : "Ada error, tetapi bukan pola yang dikenal",
                    res.rootCause, fx));
        }

        List<Finding> list = new ArrayList<Finding>(out.values());
        final Map<String, Integer> order = new LinkedHashMap<String, Integer>();
        int i = 0;
        for (Finding f : list) order.put(f.id, i++);
        Collections.sort(list, new Comparator<Finding>() {
            @Override
            public int compare(Finding a, Finding b) {
                if (a.severity != b.severity) return b.severity - a.severity;
                return order.get(a.id) - order.get(b.id);
            }
        });
        for (int k = 0; k < list.size() && k < 6; k++) res.findings.add(list.get(k));
        return res;
    }

    private static List<String> withFirst(List<String> rest, String first) {
        List<String> l = new ArrayList<String>();
        l.add(first);
        l.addAll(rest);
        return l;
    }

    private static String join(java.util.Collection<String> c) {
        StringBuilder sb = new StringBuilder();
        for (String s : c) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(s);
        }
        return sb.toString();
    }

    private static void detectEnv(String log, DeviceInfo dev, Result res) {
        Matcher m = FABRIC_ENV.matcher(log);
        String loaderVer = "";
        if (m.find()) {
            res.mcVersion = m.group(1);
            res.loader = m.group(2).toLowerCase();
            loaderVer = m.group(3);
        }
        Matcher fv = FORGE_VER.matcher(log);
        if (fv.find()) {
            res.loader = fv.group(1).equalsIgnoreCase("neoForge") ? "neoforge" : "forge";
            loaderVer = fv.group(2);
        } else if (res.loader.length() == 0) {
            if (log.contains("neoforged") || log.contains("NeoForge")) res.loader = "neoforge";
            else if (log.contains("net.minecraftforge") || log.contains("Forge Mod Loader")) res.loader = "forge";
            else if (log.contains("Quilt Loader") || log.contains("org.quiltmc")) res.loader = "quilt";
            else if (log.contains("Fabric Loader") || log.contains("net.fabricmc")) res.loader = "fabric";
        }
        if (res.mcVersion.length() == 0) {
            Matcher mc = FML_MC.matcher(log);
            if (mc.find()) {
                String g = first(mc);
                if (g != null) res.mcVersion = g;
            }
        }
        if (res.mcVersion.length() == 0 && dev.mcVersion != null) res.mcVersion = dev.mcVersion;
        Matcher jv = JAVA_VER.matcher(log);
        if (jv.find()) {
            String g = first(jv);
            if (g != null) res.javaVersion = g;
        }
        Matcher mcnt = MOD_COUNT.matcher(log);
        if (mcnt.find()) {
            String g = first(mcnt);
            if (g != null) res.modCount = Integer.parseInt(g);
        }
        StringBuilder sb = new StringBuilder();
        if (res.mcVersion.length() > 0) sb.append("Minecraft ").append(res.mcVersion);
        if (res.loader.length() > 0) {
            if (sb.length() > 0) sb.append(" | ");
            sb.append(res.loader);
            if (loaderVer.length() > 0) sb.append(' ').append(loaderVer);
        }
        if (res.javaVersion.length() > 0) {
            if (sb.length() > 0) sb.append(" | ");
            sb.append("Java ").append(res.javaVersion);
        }
        if (res.modCount >= 0) {
            if (sb.length() > 0) sb.append(" | ");
            sb.append(res.modCount).append(" mods");
        }
        res.env = sb.toString();
    }

    /** Baris penyebab paling dalam: "Caused by" terakhir, atau baris exception terakhir. */
    static String findRootCause(String log) {
        String last = "";
        Matcher m = CAUSED_BY.matcher(log);
        while (m.find()) last = m.group(1);
        if (last.length() > 0) return clip(last, 220);
        Matcher e = EXC_LINE.matcher(log);
        while (e.find()) last = e.group(1);
        return clip(last, 220);
    }
}
