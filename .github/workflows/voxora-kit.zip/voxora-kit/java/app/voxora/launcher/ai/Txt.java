package app.voxora.launcher.ai;

/** Teks dua bahasa (Indonesia / Inggris). */
public final class Txt {
    public final String id;
    public final String en;

    public Txt(String id, String en) {
        this.id = id;
        this.en = en;
    }

    public String get(String lang) {
        return "en".equals(lang) ? en : id;
    }

    public static Txt of(String id, String en) {
        return new Txt(id, en);
    }
}
