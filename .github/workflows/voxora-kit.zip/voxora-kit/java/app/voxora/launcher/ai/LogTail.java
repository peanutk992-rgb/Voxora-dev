package app.voxora.launcher.ai;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;

/** Membaca bagian akhir file log (supaya log besar tidak memenuhi memori). */
public final class LogTail {
    private LogTail() {
    }

    public static String read(File f, int maxBytes) throws IOException {
        if (f == null || !f.isFile()) return "";
        RandomAccessFile raf = new RandomAccessFile(f, "r");
        try {
            long len = raf.length();
            long start = Math.max(0L, len - maxBytes);
            raf.seek(start);
            byte[] buf = new byte[(int) (len - start)];
            raf.readFully(buf);
            String s = new String(buf, StandardCharsets.UTF_8);
            if (start > 0) {
                int nl = s.indexOf('\n');
                if (nl >= 0 && nl < s.length() - 1) s = s.substring(nl + 1);
            }
            return s;
        } finally {
            raf.close();
        }
    }
}
